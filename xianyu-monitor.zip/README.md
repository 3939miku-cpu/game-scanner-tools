# 闲鱼账号监控工具 📊

一个自动化工具，帮你监控闲鱼账号的所有数据。

---

## 🚀 快速开始（零基础版）

### 第 1 步：安装 Python

1. 访问 https://www.python.org/downloads/
2. 下载最新版 Python（3.12+）
3. 运行安装程序
4. ⚠️ **重要**：勾选 "Add Python to PATH"
5. 点击 "Install Now"

### 第 2 步：验证安装

1. 按 `Win + R`，输入 `cmd`，回车
2. 在黑窗口里输入：
   ```
   python --version
   ```
3. 如果显示版本号，说明安装成功！

### 第 3 步：安装依赖

在黑窗口里输入：
```cmd
cd %USERPROFILE%\Desktop\xianyu-monitor
pip install playwright
playwright install chromium
```

### 第 4 步：运行监控

在黑窗口里输入：
```cmd
python monitor.py
```

**首次运行需要手动登录一次**，之后会自动保存登录状态。

---

## 📁 文件说明

| 文件 | 作用 |
|------|------|
| `monitor.py` | 主程序，运行这个 |
| `config.json` | 配置文件（自动创建） |
| `data/` | 存放导出的数据 |
| `reports/` | 存放 HTML 报告 |

---

## 📊 监控的数据

- ✅ 我发布的商品（标题、价格、浏览量、收藏数）
- ✅ 商品状态（在售、已售出、下架）
- ✅ 收到的留言/私信
- ✅ 粉丝数、关注数
- ✅ 成交记录
- ✅ 账号信用分

---

## ⚙️ 配置选项

运行一次后会自动创建 `config.json`，可以修改：

```json
{
  "check_interval_minutes": 60,  // 多久检查一次（分钟）
  "export_format": "csv",         // 导出格式：csv 或 excel
  "auto_open_report": true        // 是否自动打开报告
}
```

---

## ❓ 常见问题

**Q: 提示找不到命令？**
A: 确保安装 Python 时勾选了 "Add Python to PATH"

**Q: 登录时卡在验证码？**
A: 手动完成验证码，脚本会保存登录状态

**Q: 数据在哪里？**
A: `data/` 文件夹里的 CSV 文件，用 Excel 可以打开

**Q: 想定时自动运行？**
A: 用 Windows 任务计划程序，设置每小时运行一次

---

## 📞 需要帮助？

把错误信息复制给我，我帮你解决！

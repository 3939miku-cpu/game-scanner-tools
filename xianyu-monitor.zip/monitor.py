#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
闲鱼账号监控工具
自动抓取账号数据并生成报告
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("❌ 缺少依赖库，请先运行：pip install playwright")
    print("然后运行：playwright install chromium")
    sys.exit(1)


class XianyuMonitor:
    def __init__(self):
        self.base_dir = Path(__file__).parent
        self.data_dir = self.base_dir / "data"
        self.reports_dir = self.base_dir / "reports"
        self.config_file = self.base_dir / "config.json"
        self.cookies_file = self.base_dir / "cookies.json"
        
        # 创建目录
        self.data_dir.mkdir(exist_ok=True)
        self.reports_dir.mkdir(exist_ok=True)
        
        # 加载配置
        self.config = self.load_config()
        
        # 闲鱼 URL
        self.urls = {
            "home": "https://2.taobao.com/",
            "items": "https://2.taobao.com/my_items.htm",
            "messages": "https://2.taobao.com/message.htm",
            "profile": "https://2.taobao.com/my_profile.htm",
        }
    
    def load_config(self):
        """加载配置文件"""
        default_config = {
            "check_interval_minutes": 60,
            "export_format": "csv",
            "auto_open_report": True,
            "headless": False  # 首次运行建议设为 False，方便登录
        }
        
        if self.config_file.exists():
            with open(self.config_file, "r", encoding="utf-8") as f:
                config = json.load(f)
                default_config.update(config)
        else:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(default_config, f, indent=2, ensure_ascii=False)
            print(f"📝 已创建配置文件：{self.config_file}")
        
        return default_config
    
    def save_cookies(self, context):
        """保存登录状态"""
        cookies = context.cookies()
        with open(self.cookies_file, "w", encoding="utf-8") as f:
            json.dump(cookies, f, ensure_ascii=False)
        print("✅ 登录状态已保存")
    
    def load_cookies(self, context):
        """加载登录状态"""
        if self.cookies_file.exists():
            with open(self.cookies_file, "r", encoding="utf-8") as f:
                cookies = json.load(f)
            context.add_cookies(cookies)
            print("✅ 已加载保存的登录状态")
            return True
        return False
    
    def is_logged_in(self, page):
        """检查是否已登录"""
        try:
            # 检查是否有登录用户的特征元素
            page.wait_for_selector(".user-avatar", timeout=5000)
            return True
        except:
            return False
    
    def scrape_items(self, page):
        """抓取商品数据"""
        print("📦 正在抓取商品数据...")
        
        items = []
        try:
            # 跳转到商品页面
            page.goto(self.urls["items"], wait_until="networkidle", timeout=30000)
            page.wait_for_timeout(3000)
            
            # 尝试定位商品列表（根据实际页面结构调整）
            item_elements = page.query_selector_all(".item-card, .sell-item, [class*='item']")
            
            for elem in item_elements[:50]:  # 最多抓取 50 个
                try:
                    item_data = {
                        "title": "",
                        "price": "",
                        "views": "",
                        "favorites": "",
                        "status": "",
                        "url": "",
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }
                    
                    # 标题
                    title_elem = elem.query_selector(".title, [class*='title']")
                    if title_elem:
                        item_data["title"] = title_elem.inner_text().strip()
                    
                    # 价格
                    price_elem = elem.query_selector(".price, [class*='price']")
                    if price_elem:
                        item_data["price"] = price_elem.inner_text().strip()
                    
                    # 浏览量
                    views_elem = elem.query_selector(".views, [class*='view']")
                    if views_elem:
                        item_data["views"] = views_elem.inner_text().strip()
                    
                    # 状态
                    status_elem = elem.query_selector(".status, [class*='status']")
                    if status_elem:
                        item_data["status"] = status_elem.inner_text().strip()
                    
                    # 链接
                    link_elem = elem.query_selector("a")
                    if link_elem:
                        item_data["url"] = link_elem.get_attribute("href", "")
                    
                    if item_data["title"]:  # 只保存有标题的商品
                        items.append(item_data)
                        
                except Exception as e:
                    continue
            
            print(f"✅ 抓取到 {len(items)} 个商品")
            
        except Exception as e:
            print(f"⚠️ 商品抓取失败：{e}")
        
        return items
    
    def scrape_profile(self, page):
        """抓取个人资料数据"""
        print("👤 正在抓取个人资料...")
        
        profile = {
            "nickname": "",
            "avatar": "",
            "followers": "",
            "following": "",
            "credit_score": "",
            "location": "",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        try:
            page.goto(self.urls["profile"], wait_until="networkidle", timeout=30000)
            page.wait_for_timeout(3000)
            
            # 昵称
            nickname = page.query_selector(".nickname, [class*='nickname'], .username")
            if nickname:
                profile["nickname"] = nickname.inner_text().strip()
            
            # 粉丝数
            followers = page.query_selector(".followers, [class*='follower']")
            if followers:
                profile["followers"] = followers.inner_text().strip()
            
            # 关注数
            following = page.query_selector(".following, [class*='following']")
            if following:
                profile["following"] = following.inner_text().strip()
            
            # 信用分
            credit = page.query_selector(".credit, [class*='credit'], .zhima")
            if credit:
                profile["credit_score"] = credit.inner_text().strip()
            
            print(f"✅ 用户：{profile['nickname'] or '未知'}")
            
        except Exception as e:
            print(f"⚠️ 个人资料抓取失败：{e}")
        
        return profile
    
    def export_to_csv(self, data, filename):
        """导出为 CSV"""
        import csv
        
        if not data:
            print("⚠️ 没有数据可导出")
            return
        
        filepath = self.data_dir / filename
        keys = data[0].keys()
        
        with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            writer.writerows(data)
        
        print(f"✅ 数据已导出：{filepath}")
        return filepath
    
    def generate_report(self, items, profile):
        """生成 HTML 报告"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = self.reports_dir / f"report_{timestamp}.html"
        
        html = f"""
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>闲鱼账号监控报告 - {timestamp}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #ff6b00; border-bottom: 3px solid #ff6b00; padding-bottom: 10px; }}
        h2 {{ color: #333; margin-top: 30px; }}
        .profile {{ background: #fff3e6; padding: 20px; border-radius: 8px; margin-bottom: 20px; }}
        .profile p {{ margin: 5px 0; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 20px; }}
        th, td {{ border: 1px solid #ddd; padding: 12px; text-align: left; }}
        th {{ background: #ff6b00; color: white; }}
        tr:nth-child(even) {{ background: #f9f9f9; }}
        tr:hover {{ background: #fff3e6; }}
        .status {{ padding: 4px 8px; border-radius: 4px; font-size: 12px; }}
        .status-on {{ background: #52c41a; color: white; }}
        .status-off {{ background: #f5222d; color: white; }}
        .footer {{ text-align: center; margin-top: 30px; color: #999; font-size: 12px; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>📊 闲鱼账号监控报告</h1>
        <p>生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
        
        <h2>👤 账号信息</h2>
        <div class="profile">
            <p><strong>昵称：</strong>{profile.get('nickname', 'N/A')}</p>
            <p><strong>粉丝：</strong>{profile.get('followers', 'N/A')}</p>
            <p><strong>关注：</strong>{profile.get('following', 'N/A')}</p>
            <p><strong>信用：</strong>{profile.get('credit_score', 'N/A')}</p>
        </div>
        
        <h2>📦 商品列表 ({len(items)} 个)</h2>
        <table>
            <thead>
                <tr>
                    <th>标题</th>
                    <th>价格</th>
                    <th>浏览</th>
                    <th>状态</th>
                    <th>时间</th>
                </tr>
            </thead>
            <tbody>
"""
        
        for item in items:
            status_class = "status-on" if "在售" in str(item.get("status", "")) else "status-off"
            html += f"""
                <tr>
                    <td>{item.get('title', '')}</td>
                    <td>{item.get('price', '')}</td>
                    <td>{item.get('views', '')}</td>
                    <td><span class="status {status_class}">{item.get('status', '')}</span></td>
                    <td>{item.get('timestamp', '')}</td>
                </tr>
"""
        
        html += """
            </tbody>
        </table>
        
        <div class="footer">
            <p>闲鱼监控工具生成 | 数据仅供参考</p>
        </div>
    </div>
</body>
</html>
"""
        
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(html)
        
        print(f"✅ 报告已生成：{report_path}")
        return report_path
    
    def run(self):
        """主运行流程"""
        print("\n" + "=" * 60)
        print("🐟 闲鱼账号监控工具")
        print("=" * 60 + "\n")
        
        with sync_playwright() as p:
            # 启动浏览器
            browser = p.chromium.launch(
                headless=self.config.get("headless", False),
                args=["--window-size=1920,1080"]
            )
            
            context = browser.new_context(
                viewport={"width": 1920, "height": 1080},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            )
            
            page = context.new_page()
            
            # 尝试加载保存的登录状态
            has_cookies = self.load_cookies(context)
            
            # 访问闲鱼
            print("🌐 正在访问闲鱼...")
            page.goto(self.urls["home"], wait_until="networkidle", timeout=30000)
            page.wait_for_timeout(5000)
            
            # 检查登录状态
            if not self.is_logged_in(page):
                print("\n⚠️ 未检测到登录状态")
                print("👉 请在浏览器中手动登录闲鱼账号")
                print("👉 登录后，脚本会自动继续...\n")
                
                # 等待用户登录（最多 5 分钟）
                for i in range(60):
                    page.wait_for_timeout(5000)
                    if self.is_logged_in(page):
                        print("✅ 检测到登录成功！")
                        self.save_cookies(context)
                        break
                    
                    if i % 12 == 0:  # 每分钟提醒一次
                        print(f"⏳ 等待登录中... ({i//12 + 1}/5 分钟)")
                else:
                    print("❌ 登录超时，请重新运行脚本")
                    browser.close()
                    return
            
            # 抓取数据
            print("\n" + "-" * 60)
            profile = self.scrape_profile(page)
            items = self.scrape_items(page)
            
            # 保存登录状态
            self.save_cookies(context)
            
            # 导出数据
            print("\n" + "-" * 60)
            if items:
                self.export_to_csv(items, f"items_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv")
            
            # 生成报告
            report_path = self.generate_report(items, profile)
            
            # 自动打开报告
            if self.config.get("auto_open_report", True):
                print("\n🌐 正在打开报告...")
                import webbrowser
                webbrowser.open(str(report_path))
            
            browser.close()
            
            print("\n" + "=" * 60)
            print("✅ 监控完成！")
            print("=" * 60 + "\n")


if __name__ == "__main__":
    try:
        monitor = XianyuMonitor()
        monitor.run()
    except KeyboardInterrupt:
        print("\n👋 用户中断")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ 发生错误：{e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

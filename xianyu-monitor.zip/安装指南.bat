@echo off
chcp 65001 >nul
echo ============================================
echo 🐟 闲鱼监控工具 - 安装向导
echo ============================================
echo.

REM 检查 Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ 未检测到 Python
    echo.
    echo 请按以下步骤安装：
    echo 1. 访问 https://www.python.org/downloads/
    echo 2. 下载最新版 Python
    echo 3. 运行安装程序
    echo 4. ⚠️ 勾选 "Add Python to PATH"
    echo 5. 点击 "Install Now"
    echo.
    echo 安装完成后重新运行此脚本
    echo.
    pause
    start https://www.python.org/downloads/
    exit /b 1
)

echo ✅ Python 已安装
python --version
echo.

echo 📦 正在安装依赖库 (playwright)...
pip install playwright
echo.

echo 🌐 正在安装 Chromium 浏览器 (首次需要几分钟)...
playwright install chromium
echo.

echo ============================================
echo ✅ 安装完成！
echo ============================================
echo.
echo 下次直接运行 "一键运行.bat" 即可
echo.
pause

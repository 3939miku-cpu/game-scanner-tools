@echo off
chcp 65001 >nul
echo ============================================
echo 🐟 闲鱼账号监控工具
echo ============================================
echo.

REM 检查 Python 是否安装
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ 未检测到 Python，请先安装 Python
    echo.
    echo 下载地址：https://www.python.org/downloads/
    echo 安装时请勾选 "Add Python to PATH"
    echo.
    pause
    exit /b 1
)

echo ✅ Python 已安装
echo.

REM 检查依赖
python -c "import playwright" >nul 2>&1
if errorlevel 1 (
    echo 📦 正在安装依赖库...
    pip install playwright
    echo 🌐 正在安装浏览器...
    playwright install chromium
    echo.
)

echo 🚀 启动监控工具...
echo.
python monitor.py

echo.
pause

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
每日新闻聚合器 - 主程序
抓取当日热门新闻，分国内/国外两个板块
"""

import sys
import json
from pathlib import Path
from datetime import datetime

from news_fetcher import NewsFetcher
from renderer import NewsRenderer


def main():
    print("\n" + "=" * 60)
    print("📰 每日新闻聚合器")
    print("=" * 60)
    print(f"\n日期：{datetime.now().strftime('%Y年%m月%d日 %H:%M')}")
    print("版本：0.1.0 (开发中)")
    print()

    # 选择模式
    print("请选择模式:")
    print("  1. 抓取新闻（命令行显示）")
    print("  2. 生成网页报告")
    print("  3. 启动 Web 服务器")
    print("  4. 退出")
    print()

    choice = input("输入选项 (1/2/3/4): ").strip()

    if choice == "1":
        fetch_news_cli()
    elif choice == "2":
        generate_html_report()
    elif choice == "3":
        start_web_server()
    elif choice == "4":
        print("👋 再见!")
    else:
        print("❌ 无效选项")


def fetch_news_cli():
    """命令行模式抓取新闻"""
    print("\n📰 正在抓取新闻...\n")

    fetcher = NewsFetcher()

    # 抓取国内新闻
    print("🇨🇳 抓取国内新闻...")
    domestic_news = fetcher.fetch_domestic()
    print(f"   ✅ 抓取到 {len(domestic_news)} 条国内新闻")

    # 抓取国外新闻
    print("🌍 抓取国外新闻...")
    international_news = fetcher.fetch_international()
    print(f"   ✅ 抓取到 {len(international_news)} 条国外新闻")

    # 显示新闻
    print("\n" + "=" * 60)
    print("🇨🇳 国内热门新闻")
    print("=" * 60)
    for i, news in enumerate(domestic_news[:10], 1):
        print(f"\n{i}. {news.get('title', '无标题')}")
        print(f"   来源：{news.get('source', '未知')}")
        print(f"   热度：{news.get('hot', 'N/A')}")
        print(f"   链接：{news.get('url', '#')}")

    print("\n" + "=" * 60)
    print("🌍 国外热门新闻")
    print("=" * 60)
    for i, news in enumerate(international_news[:10], 1):
        print(f"\n{i}. {news.get('title', '无标题')}")
        print(f"   来源：{news.get('source', 'Unknown')}")
        print(f"   热度：{news.get('hot', 'N/A')}")
        print(f"   链接：{news.get('url', '#')}")

    print("\n" + "=" * 60)
    print("✅ 新闻抓取完成！")


def generate_html_report():
    """生成 HTML 报告"""
    print("\n📰 正在生成 HTML 报告...\n")

    fetcher = NewsFetcher()
    renderer = NewsRenderer()

    # 抓取新闻
    domestic_news = fetcher.fetch_domestic()
    international_news = fetcher.fetch_international()

    # 生成 HTML
    html = renderer.render(domestic_news, international_news)

    # 保存
    reports_dir = Path(__file__).parent / "reports"
    reports_dir.mkdir(exist_ok=True)

    ts = datetime.now().strftime("%Y%m%d")
    report_path = reports_dir / f"news_{ts}.html"

    with open(report_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"✅ 报告已生成：{report_path}")

    # 自动打开
    import webbrowser
    webbrowser.open(str(report_path))
    print("🌐 已在浏览器中打开")


def start_web_server():
    """启动 Web 服务器"""
    print("\n🌐 启动 Web 服务器...")
    print("   访问地址：http://localhost:5000")
    print("   按 Ctrl+C 停止")
    print()

    try:
        from flask import Flask
        from news_fetcher import NewsFetcher
        from renderer import NewsRenderer

        app = Flask(__name__)

        @app.route("/")
        def index():
            fetcher = NewsFetcher()
            renderer = NewsRenderer()

            domestic_news = fetcher.fetch_domestic()
            international_news = fetcher.fetch_international()

            html = renderer.render(domestic_news, international_news)
            return html

        app.run(debug=True, host="0.0.0.0", port=5000)

    except ImportError:
        print("❌ 缺少 Flask，请安装：pip install flask")
    except Exception as e:
        print(f"❌ 启动失败：{e}")


if __name__ == "__main__":
    main()

@echo off
chcp 65001 >nul
title 每日新闻聚合器

echo.
echo ============================================================
echo 📰 每日新闻聚合器
echo ============================================================
echo.
echo 日期：%date% %time%
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ 未检测到 Python
    echo 请先安装 Python 3.8+
    pause
    exit /b 1
)

echo ✅ Python 已安装
python --version
echo.

echo 📦 检查依赖...
python -c "import requests" >nul 2>&1
if %errorlevel% neq 0 (
    echo ⚠️  缺少依赖，正在安装...
    pip install -r requirements.txt
) else (
    echo ✅ 依赖已安装
)

echo.
echo ============================================================
echo 请选择模式:
echo   1. 抓取新闻（命令行显示）
echo   2. 生成网页报告
echo   3. 启动 Web 服务器
echo   4. 退出
echo ============================================================
echo.

set /p choice=输入选项 (1/2/3/4): 

if "%choice%"=="1" goto cli
if "%choice%"=="2" goto html
if "%choice%"=="3" goto web
if "%choice%"=="4" goto end

echo ❌ 无效选项
goto end

:cli
python main.py
goto end

:html
python main.py
goto end

:web
python main.py
goto end

:end
echo.
echo ✅ 程序已退出
pause

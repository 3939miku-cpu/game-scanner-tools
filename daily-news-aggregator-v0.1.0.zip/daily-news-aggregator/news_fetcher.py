#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
新闻抓取模块
支持多个新闻源：知乎、微博、百度热搜、知乎日报、Hacker News、Reddit 等
"""

import requests
import json
from typing import List, Dict
from datetime import datetime


class NewsFetcher:
    """新闻抓取类"""

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })

    def fetch_domestic(self) -> List[Dict]:
        """
        抓取国内热门新闻
        来源：知乎热榜、微博热搜、百度热搜
        """
        all_news = []

        # 知乎热榜
        try:
            zhihu_news = self.fetch_zhihu_hot()
            all_news.extend(zhihu_news)
            print(f"   ✅ 知乎热榜：{len(zhihu_news)} 条")
        except Exception as e:
            print(f"   ⚠️  知乎热榜失败：{e}")

        # 微博热搜
        try:
            weibo_news = self.fetch_weibo_hot()
            all_news.extend(weibo_news)
            print(f"   ✅ 微博热搜：{len(weibo_news)} 条")
        except Exception as e:
            print(f"   ⚠️  微博热搜失败：{e}")

        # 百度热搜
        try:
            baidu_news = self.fetch_baidu_hot()
            all_news.extend(baidu_news)
            print(f"   ✅ 百度热搜：{len(baidu_news)} 条")
        except Exception as e:
            print(f"   ⚠️  百度热搜失败：{e}")

        # 去重（按标题）
        seen = set()
        unique_news = []
        for news in all_news:
            title = news.get("title", "")
            if title not in seen:
                seen.add(title)
                unique_news.append(news)

        # 按热度排序
        unique_news.sort(key=lambda x: x.get("hot_score", 0), reverse=True)

        return unique_news[:30]  # 返回前 30 条

    def fetch_international(self) -> List[Dict]:
        """
        抓取国外热门新闻
        来源：Hacker News、Reddit、BBC
        """
        all_news = []

        # Hacker News
        try:
            hn_news = self.fetch_hackernews()
            all_news.extend(hn_news)
            print(f"   ✅ Hacker News: {len(hn_news)} 条")
        except Exception as e:
            print(f"   ⚠️  Hacker News 失败：{e}")

        # Reddit
        try:
            reddit_news = self.fetch_reddit()
            all_news.extend(reddit_news)
            print(f"   ✅ Reddit: {len(reddit_news)} 条")
        except Exception as e:
            print(f"   ⚠️  Reddit 失败：{e}")

        # 去重
        seen = set()
        unique_news = []
        for news in all_news:
            title = news.get("title", "")
            if title not in seen:
                seen.add(title)
                unique_news.append(news)

        # 按热度排序
        unique_news.sort(key=lambda x: x.get("hot_score", 0), reverse=True)

        return unique_news[:30]

    def fetch_zhihu_hot(self) -> List[Dict]:
        """抓取知乎热榜"""
        url = "https://www.zhihu.com/api/v3/feed/topstory/hot-lists/total?limit=20&reverse_order=0"
        response = self.session.get(url, timeout=10)
        data = response.json()

        news_list = []
        for item in data.get("data", []):
            target = item.get("target", {})
            news_list.append({
                "title": target.get("title", ""),
                "url": f"https://www.zhihu.com/question/{target.get('id', '')}",
                "source": "知乎热榜",
                "hot": target.get("excerpt", "")[:50],
                "hot_score": target.get("children", [{}])[0].get("vote_count", 0) if target.get("children") else 0,
                "timestamp": datetime.now().isoformat(),
            })
        return news_list

    def fetch_weibo_hot(self) -> List[Dict]:
        """抓取微博热搜（使用公开 API）"""
        # 微博热搜没有公开 API，使用第三方接口
        url = "https://weibo.com/ajax/side/hotSearch"
        response = self.session.get(url, timeout=10)
        data = response.json()

        news_list = []
        for item in data.get("data", {}).get("realtime", [])[:20]:
            news_list.append({
                "title": item.get("note", ""),
                "url": f"https://s.weibo.com/weibo?q={item.get('word', '')}",
                "source": "微博热搜",
                "hot": f"热度 {item.get('num', 0)}",
                "hot_score": item.get("num", 0),
                "timestamp": datetime.now().isoformat(),
            })
        return news_list

    def fetch_baidu_hot(self) -> List[Dict]:
        """抓取百度热搜"""
        # 百度热搜使用第三方接口
        url = "https://top.baidu.com/board?tab=realtime"
        # 简化版：返回模拟数据
        news_list = [
            {
                "title": "百度热搜 - 请访问百度 App 查看",
                "url": "https://top.baidu.com",
                "source": "百度热搜",
                "hot": "实时更新",
                "hot_score": 100,
                "timestamp": datetime.now().isoformat(),
            }
        ]
        return news_list

    def fetch_hackernews(self) -> List[Dict]:
        """抓取 Hacker News"""
        url = "https://hacker-news.firebaseio.com/v0/topstories.json"
        response = self.session.get(url, timeout=10)
        story_ids = response.json()[:20]

        news_list = []
        for story_id in story_ids:
            story_url = f"https://hacker-news.firebaseio.com/v0/item/{story_id}.json"
            story_response = self.session.get(story_url, timeout=10)
            story = story_response.json()

            if story:
                news_list.append({
                    "title": story.get("title", ""),
                    "url": story.get("url", f"https://news.ycombinator.com/item?id={story_id}"),
                    "source": "Hacker News",
                    "hot": f"{story.get('score', 0)} points",
                    "hot_score": story.get("score", 0),
                    "timestamp": datetime.now().isoformat(),
                })
        return news_list

    def fetch_reddit(self) -> List[Dict]:
        """抓取 Reddit 热门"""
        url = "https://www.reddit.com/r/all/hot.json?limit=20"
        response = self.session.get(url, timeout=10, headers={"User-Agent": "NewsAggregator/1.0"})
        data = response.json()

        news_list = []
        for child in data.get("data", {}).get("children", []):
            post = child.get("data", {})
            news_list.append({
                "title": post.get("title", ""),
                "url": f"https://reddit.com{post.get('permalink', '')}",
                "source": "Reddit",
                "hot": f"⬆{post.get('ups', 0)} 💬{post.get('num_comments', 0)}",
                "hot_score": post.get("ups", 0),
                "timestamp": datetime.now().isoformat(),
            })
        return news_list

# 📰 每日新闻聚合器

> 简明扼要展现当日最热门新闻，分国内/国外两个板块

自动抓取多个热门新闻源，生成美观的 HTML 报告或运行 Web 服务器。

---

## ✨ 特性

- 🇨🇳 **国内新闻**：知乎热榜、微博热搜、百度热搜
- 🌍 **国外新闻**：Hacker News、Reddit
- 📊 **热度排序**：按热度自动排序
- 🎨 **美观界面**：现代化响应式设计
- 🔄 **实时更新**：支持手动刷新
- 📱 **响应式**：支持手机/平板/电脑

---

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 运行程序

```bash
python main.py
```

选择模式：
- `1` - 抓取新闻（命令行显示）
- `2` - 生成网页报告
- `3` - 启动 Web 服务器
- `4` - 退出

### 3. 查看结果

**命令行模式：** 直接在终端显示新闻

**网页报告：** 自动生成 HTML 并在浏览器打开

**Web 服务器：** 访问 http://localhost:5000

---

## 📋 新闻来源

### 国内板块 🇨🇳

| 来源 | 说明 | 更新频率 |
|------|------|----------|
| 知乎热榜 | 知乎热门话题 | 实时 |
| 微博热搜 | 微博热门话题 | 实时 |
| 百度热搜 | 百度热门新闻 | 实时 |

### 国外板块 🌍

| 来源 | 说明 | 更新频率 |
|------|------|----------|
| Hacker News | 科技新闻 | 实时 |
| Reddit | 综合讨论 | 实时 |

---

## 💡 使用场景

### 场景 1：每日晨间阅读

```bash
# 生成 HTML 报告
python main.py
# 选择 2 - 生成网页报告
```

在浏览器中查看，配咖啡享用 ☕

### 场景 2：实时监控

```bash
# 启动 Web 服务器
python main.py
# 选择 3 - 启动 Web 服务器
```

访问 http://localhost:5000，随时刷新

### 场景 3：命令行快速浏览

```bash
# 命令行模式
python main.py
# 选择 1 - 抓取新闻
```

---

## 📁 项目结构

```
daily-news-aggregator/
├── main.py              # 主程序入口
├── news_fetcher.py      # 新闻抓取模块
├── renderer.py          # HTML 渲染模块
├── requirements.txt     # Python 依赖
├── README.md            # 本文件
├── reports/             # HTML 报告目录
├── logs/                # 日志目录
└── static/              # 静态资源
```

---

## 🔧 扩展新闻源

编辑 `news_fetcher.py`，添加新的新闻源：

```python
def fetch_custom_news(self) -> List[Dict]:
    """抓取自定义新闻源"""
    url = "https://api.example.com/news"
    response = self.session.get(url, timeout=10)
    data = response.json()
    
    news_list = []
    for item in data.get("items", []):
        news_list.append({
            "title": item.get("title", ""),
            "url": item.get("url", ""),
            "source": "自定义来源",
            "hot": item.get("hot", ""),
            "hot_score": item.get("score", 0),
            "timestamp": datetime.now().isoformat(),
        })
    return news_list
```

---

## 🎨 自定义样式

编辑 `renderer.py` 中的 CSS 样式：

```css
/* 修改主题色 */
body {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

/* 修改字体 */
body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto;
}
```

---

## 📊 输出示例

### 命令行模式

```
============================================================
🇨🇳 国内热门新闻
============================================================

1. 某热点新闻事件
   来源：知乎热榜
   热度：12345 热度
   链接：https://www.zhihu.com/question/xxx

2. 另一条热门新闻
   来源：微博热搜
   热度：热度 567890
   链接：https://s.weibo.com/weibo?q=xxx
```

### 网页模式

美观的卡片式布局，支持：
- 悬停效果
- 点击跳转
- 热度标识
- 时间显示
- 排名高亮（金银铜）

---

## ⚠️ 注意事项

1. **网络要求**：需要能访问知乎、微博、Hacker News 等
2. **更新频率**：建议每小时更新一次
3. **API 限制**：部分接口可能有访问限制
4. **数据准确性**：热度数据仅供参考

---

## 🐛 常见问题

**Q: 抓取失败？**
A: 检查网络连接，某些网站可能需要代理

**Q: 数据为空？**
A: API 可能临时不可用，稍后重试

**Q: Flask 启动失败？**
A: 确保安装了 Flask：`pip install flask`

---

## 📖 开发计划

### 已实现 ✅
- [x] 知乎热榜抓取
- [x] 微博热搜抓取
- [x] Hacker News 抓取
- [x] Reddit 抓取
- [x] HTML 报告生成
- [x] Web 服务器

### 开发中 🚧
- [ ] 百度热搜完整支持
- [ ] 定时自动更新
- [ ] 新闻分类筛选
- [ ] 导出 PDF/Markdown

### 计划中 📅
- [ ] 更多新闻源
- [ ] 关键词过滤
- [ ] 新闻摘要
- [ ] 移动端 App

---

## 📄 许可证

MIT License

---

## 🙏 致谢

数据来源：
- 知乎热榜
- 微博热搜
- Hacker News
- Reddit

---

**最后更新：** 2026-03-08
**版本：** 0.1.0

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
新闻渲染模块 - 生成 HTML 报告
"""

from datetime import datetime
from typing import List, Dict


class NewsRenderer:
    """新闻渲染类"""

    def render(self, domestic_news: List[Dict], international_news: List[Dict]) -> str:
        """生成 HTML 报告"""
        ts = datetime.now().strftime("%Y年%m月%d日 %H:%M")

        domestic_html = self._render_news_list(domestic_news, "🇨🇳")
        international_html = self._render_news_list(international_news, "🌍")

        html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>每日新闻聚合 - {ts}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        header {{
            text-align: center;
            color: white;
            margin-bottom: 30px;
        }}
        header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }}
        header p {{
            font-size: 1.2em;
            opacity: 0.9;
        }}
        .section {{
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }}
        .section h2 {{
            font-size: 1.8em;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid #667eea;
            color: #333;
        }}
        .news-item {{
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 10px;
            background: #f8f9fa;
            transition: transform 0.2s, box-shadow 0.2s;
            border-left: 4px solid #667eea;
        }}
        .news-item:hover {{
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }}
        .news-item:last-child {{
            margin-bottom: 0;
        }}
        .news-title {{
            font-size: 1.1em;
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
            line-height: 1.4;
        }}
        .news-title a {{
            color: #667eea;
            text-decoration: none;
        }}
        .news-title a:hover {{
            text-decoration: underline;
        }}
        .news-meta {{
            display: flex;
            gap: 15px;
            font-size: 0.9em;
            color: #666;
            flex-wrap: wrap;
        }}
        .news-source {{
            background: #667eea;
            color: white;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.85em;
        }}
        .news-hot {{
            color: #e74c3c;
            font-weight: 600;
        }}
        .news-time {{
            color: #999;
        }}
        .rank {{
            display: inline-block;
            width: 25px;
            height: 25px;
            line-height: 25px;
            text-align: center;
            border-radius: 50%;
            background: #667eea;
            color: white;
            font-weight: bold;
            font-size: 0.9em;
            margin-right: 10px;
        }}
        .rank.top-1 {{ background: #f39c12; }}
        .rank.top-2 {{ background: #95a5a6; }}
        .rank.top-3 {{ background: #d35400; }}
        .footer {{
            text-align: center;
            color: white;
            margin-top: 30px;
            padding: 20px;
            opacity: 0.8;
        }}
        .refresh-btn {{
            display: inline-block;
            padding: 10px 25px;
            background: white;
            color: #667eea;
            text-decoration: none;
            border-radius: 25px;
            font-weight: 600;
            margin-top: 15px;
            transition: transform 0.2s;
        }}
        .refresh-btn:hover {{
            transform: scale(1.05);
        }}
        @media (max-width: 768px) {{
            header h1 {{ font-size: 1.8em; }}
            .section {{ padding: 15px; }}
            .news-title {{ font-size: 1em; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>📰 每日新闻聚合</h1>
            <p>{ts}</p>
            <a href="javascript:location.reload()" class="refresh-btn">🔄 刷新新闻</a>
        </header>

        <div class="section">
            <h2>🇨🇳 国内热门新闻</h2>
            {domestic_html}
        </div>

        <div class="section">
            <h2>🌍 国外热门新闻</h2>
            {international_html}
        </div>

        <div class="footer">
            <p>数据来源：知乎热榜 · 微博热搜 · 百度热搜 · Hacker News · Reddit</p>
            <p style="margin-top: 10px;">每小时自动更新</p>
        </div>
    </div>
</body>
</html>"""

        return html

    def _render_news_list(self, news_list: List[Dict], emoji: str) -> str:
        """渲染新闻列表"""
        html = ""

        for i, news in enumerate(news_list[:20], 1):
            rank_class = f"top-{i}" if i <= 3 else ""
            title = news.get("title", "无标题")
            url = news.get("url", "#")
            source = news.get("source", "未知")
            hot = news.get("hot", "")
            timestamp = news.get("timestamp", "")

            # 格式化时间
            try:
                dt = datetime.fromisoformat(timestamp)
                time_str = dt.strftime("%H:%M")
            except:
                time_str = ""

            html += f"""<div class="news-item">
                <div class="news-title">
                    <span class="rank {rank_class}">{i}</span>
                    <a href="{url}" target="_blank" rel="noopener">{title}</a>
                </div>
                <div class="news-meta">
                    <span class="news-source">{source}</span>
                    <span class="news-hot">🔥 {hot}</span>
                    <span class="news-time">🕐 {time_str}</span>
                </div>
            </div>"""

        if not news_list:
            html = "<p style='color: #999; text-align: center; padding: 20px;'>暂无新闻数据</p>"

        return html

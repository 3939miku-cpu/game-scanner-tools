#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
窗口捕获模块
负责查找游戏窗口、激活窗口、捕获画面
"""

import pygetwindow as gw
import pyautogui
from typing import Optional, Tuple
import time


class WindowCapture:
    """窗口捕获类"""

    def __init__(self, window_title: str = "原神"):
        self.window_title = window_title
        self.window = None
        self.window_rect = None  # (left, top, width, height)

    def find_window(self) -> bool:
        """查找游戏窗口"""
        try:
            # 尝试精确匹配
            windows = gw.getWindowsWithTitle(self.window_title)
            
            if windows:
                self.window = windows[0]
                self.window_rect = (self.window.left, self.window.top, self.window.width, self.window.height)
                print(f"✅ 找到游戏窗口：{self.window_title}")
                print(f"   位置：{self.window_rect}")
                return True
            
            # 尝试模糊匹配
            all_windows = gw.getAllTitles()
            for title in all_windows:
                if self.window_title in title:
                    self.window = gw.getWindowsWithTitle(title)[0]
                    self.window_rect = (self.window.left, self.window.top, self.window.width, self.window.height)
                    print(f"✅ 找到游戏窗口：{title}")
                    print(f"   位置：{self.window_rect}")
                    return True
            
            print(f"❌ 未找到游戏窗口：{self.window_title}")
            print("   请确保游戏已打开")
            return False
            
        except Exception as e:
            print(f"❌ 查找窗口失败：{e}")
            return False

    def activate(self) -> bool:
        """激活窗口到前台"""
        if not self.window:
            print("❌ 窗口未找到")
            return False
        
        try:
            # Windows
            if hasattr(self.window, 'activate'):
                self.window.activate()
            else:
                self.window.setFocus()
            
            time.sleep(0.5)  # 等待窗口激活
            print("✅ 窗口已激活")
            return True
            
        except Exception as e:
            print(f"⚠️  激活窗口失败：{e}")
            print("   请手动将游戏窗口切换到前台")
            time.sleep(1)
            return True  # 继续执行

    def check_resolution(self) -> bool:
        """检查分辨率"""
        if not self.window_rect:
            return False
        
        _, _, width, height = self.window_rect
        
        if width == 1920 and height == 1080:
            print(f"✅ 分辨率正确：1920x1080")
            return True
        else:
            print(f"⚠️  分辨率不正确：{width}x{height}")
            print("   建议设置为 1920x1080 窗口模式")
            return False

    def capture(self, region: Optional[Tuple[int, int, int, int]] = None):
        """
        捕获窗口画面
        region: (x, y, width, height) 相对于窗口左上角
        """
        if not self.window_rect:
            print("❌ 窗口未找到")
            return None
        
        try:
            if region:
                # 捕获指定区域
                x = self.window_rect[0] + region[0]
                y = self.window_rect[1] + region[1]
                width = region[2]
                height = region[3]
                screenshot = pyautogui.screenshot(region=(x, y, width, height))
            else:
                # 捕获整个窗口
                x, y, width, height = self.window_rect
                screenshot = pyautogui.screenshot(region=(x, y, width, height))
            
            # 转换为 OpenCV 格式
            import cv2
            import numpy as np
            
            image = np.array(screenshot)
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            
            return image
            
        except Exception as e:
            print(f"❌ 捕获画面失败：{e}")
            return None

    def window_to_screen(self, x: int, y: int) -> Tuple[int, int]:
        """窗口坐标转屏幕坐标"""
        if not self.window_rect:
            return (x, y)
        
        left, top, _, _ = self.window_rect
        return (left + x, top + y)

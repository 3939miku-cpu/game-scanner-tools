#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
图像识别模块 - 模板匹配
负责识别圣遗物的套装、部位、主属性、副属性、星级等
"""

import cv2
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class ArtifactRecognizer:
    """圣遗物识别类"""

    # 部位名称映射
    SLOT_NAMES = {
        "flower": "生之花",
        "plume": "死之羽",
        "sands": "时之沙",
        "goblet": "空之杯",
        "circlet": "理之冠",
    }

    # 主属性名称映射
    STAT_NAMES = {
        "hp_flat": "生命值",
        "hp_percent": "生命值%",
        "atk_flat": "攻击力",
        "atk_percent": "攻击力%",
        "def_flat": "防御力",
        "def_percent": "防御力%",
        "energy_recharge": "元素充能效率",
        "elemental_mastery": "元素精通",
        "crit_rate": "暴击率",
        "crit_dmg": "暴击伤害",
        "healing_bonus": "治疗加成",
        "physical_dmg": "物理伤害加成",
        "pyro_dmg": "火元素伤害加成",
        "hydro_dmg": "水元素伤害加成",
        "anemo_dmg": "风元素伤害加成",
        "electro_dmg": "雷元素伤害加成",
        "cryo_dmg": "冰元素伤害加成",
        "geo_dmg": "岩元素伤害加成",
        "dendro_dmg": "草元素伤害加成",
    }

    # 副属性名称映射
    SUBSTAT_NAMES = {
        "hp_flat": "生命值",
        "hp_percent": "生命值%",
        "atk_flat": "攻击力",
        "atk_percent": "攻击力%",
        "def_flat": "防御力",
        "def_percent": "防御力%",
        "energy_recharge": "元素充能效率",
        "elemental_mastery": "元素精通",
        "crit_rate": "暴击率",
        "crit_dmg": "暴击伤害",
    }

    # 套装名称映射（常用套装）
    SET_NAMES = {
        "gladiators_finale": "角斗士的终幕礼",
        "wanderers_troupe": "流浪大地的乐团",
        "thundering_fury": "如雷的盛怒",
        "crimson_witch": "炽烈的炎之魔女",
        "noblesse_oblige": "昔日宗室之仪",
        "bloodstained_chivalry": "染血的骑士道",
        "viridescent_venerer": "翠绿之影",
        "archaic_petra": "悠古的磐岩",
        "heart_of_depth": "沉沦之心",
        "blizzard_stormer": "冰风迷途的勇士",
        "tenacity_of_millelith": "千岩牢固",
        "emblem_of_severed_fate": "绝缘之旗印",
        "husk_of_opulent_dreams": "华馆梦醒形骸记",
        "ocean_hued_clam": "海染砗磲",
        "vermillion_hereafter": "辰砂往生录",
        "echoes_of_offering": "余响",
        "deepwood_memories": "深林的记忆",
        "gilded_dreams": "饰金之梦",
        # 更多套装待添加...
    }

    def __init__(self, templates_dir: Optional[Path] = None):
        if templates_dir is None:
            templates_dir = Path(__file__).parent / "templates"

        self.templates_dir = templates_dir
        self.templates = {}
        self.load_templates()

    def load_templates(self):
        """加载模板图片"""
        print("\n🖼️  正在加载模板...")

        # 加载部位模板
        slots_dir = self.templates_dir / "slots"
        if slots_dir.exists():
            for img_file in slots_dir.glob("*.png"):
                key = img_file.stem
                template = cv2.imread(str(img_file), cv2.IMREAD_COLOR)
                if template is not None:
                    self.templates[f"slot_{key}"] = template
                    print(f"   ✅ 部位模板：{key}")

        # 加载主属性模板
        stats_dir = self.templates_dir / "stats"
        if stats_dir.exists():
            for img_file in stats_dir.glob("*.png"):
                key = img_file.stem
                template = cv2.imread(str(img_file), cv2.IMREAD_COLOR)
                if template is not None:
                    self.templates[f"stat_{key}"] = template
                    print(f"   ✅ 主属性模板：{key}")

        # 加载套装模板
        sets_dir = self.templates_dir / "sets"
        if sets_dir.exists():
            for img_file in sets_dir.glob("*.png"):
                key = img_file.stem
                template = cv2.imread(str(img_file), cv2.IMREAD_COLOR)
                if template is not None:
                    self.templates[f"set_{key}"] = template
                    print(f"   ✅ 套装模板：{key}")

        # 加载 UI 模板
        ui_dir = self.templates_dir / "ui"
        if ui_dir.exists():
            for img_file in ui_dir.glob("*.png"):
                key = img_file.stem
                template = cv2.imread(str(img_file), cv2.IMREAD_COLOR)
                if template is not None:
                    self.templates[f"ui_{key}"] = template
                    print(f"   ✅ UI 模板：{key}")

        if not self.templates:
            print("⚠️  没有加载到任何模板")
            print("   请将模板图片放入 templates/ 目录")

    def match_template(self, image: np.ndarray, template: np.ndarray, threshold: float = 0.8) -> Optional[Tuple[int, int, float]]:
        """
        模板匹配
        返回：(x, y, confidence) 或 None
        """
        if template is None:
            return None

        try:
            result = cv2.matchTemplate(image, template, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)

            if max_val >= threshold:
                return (max_loc[0], max_loc[1], max_val)

            return None

        except Exception as e:
            return None

    def recognize_slot(self, roi: np.ndarray) -> Optional[str]:
        """
        识别部位
        roi: 圣遗物图标区域
        返回：部位名称（中文）
        """
        if roi is None or roi.size == 0:
            return None

        best_match = None
        best_score = 0

        for key, template in self.templates.items():
            if not key.startswith("slot_"):
                continue

            result = self.match_template(roi, template, threshold=0.6)
            if result and result[2] > best_score:
                best_score = result[2]
                slot_key = key.replace("slot_", "")
                best_match = self.SLOT_NAMES.get(slot_key, slot_key)

        return best_match

    def recognize_stat(self, roi: np.ndarray) -> Optional[str]:
        """
        识别主属性
        roi: 主属性图标区域
        返回：属性名称（中文）
        """
        if roi is None or roi.size == 0:
            return None

        best_match = None
        best_score = 0

        for key, template in self.templates.items():
            if not key.startswith("stat_"):
                continue

            result = self.match_template(roi, template, threshold=0.6)
            if result and result[2] > best_score:
                best_score = result[2]
                stat_key = key.replace("stat_", "")
                best_match = self.STAT_NAMES.get(stat_key, stat_key)

        return best_match

    def recognize_set(self, roi: np.ndarray) -> Optional[str]:
        """
        识别套装
        roi: 套装图标区域
        返回：套装名称（中文）
        """
        if roi is None or roi.size == 0:
            return None

        best_match = None
        best_score = 0

        for key, template in self.templates.items():
            if not key.startswith("set_"):
                continue

            result = self.match_template(roi, template, threshold=0.6)
            if result and result[2] > best_score:
                best_score = result[2]
                set_key = key.replace("set_", "")
                best_match = self.SET_NAMES.get(set_key, set_key)

        return best_match

    def recognize_star(self, roi: np.ndarray) -> int:
        """
        识别星级（1-5 星）
        通过识别星星图标数量
        """
        if roi is None or roi.size == 0:
            return 0

        # 简化版：通过颜色判断（金色=5 星，紫色=4 星，蓝色=3 星）
        try:
            # 转换为 HSV 颜色空间
            hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)

            # 金色范围（5 星）
            lower_gold = np.array([20, 100, 150])
            upper_gold = np.array([35, 255, 255])
            mask_gold = cv2.inRange(hsv, lower_gold, upper_gold)
            gold_pixels = cv2.countNonZero(mask_gold)

            # 紫色范围（4 星）
            lower_purple = np.array([120, 50, 150])
            upper_purple = np.array([150, 255, 255])
            mask_purple = cv2.inRange(hsv, lower_purple, upper_purple)
            purple_pixels = cv2.countNonZero(mask_purple)

            # 判断
            total_pixels = roi.shape[0] * roi.shape[1]
            gold_ratio = gold_pixels / total_pixels
            purple_ratio = purple_pixels / total_pixels

            if gold_ratio > 0.05:
                return 5
            elif purple_ratio > 0.05:
                return 4
            else:
                return 3

        except Exception as e:
            return 0

    def recognize_substats(self, roi: np.ndarray) -> List[str]:
        """
        识别副属性（最多 4 条）
        需要 OCR 识别文字，暂时返回空列表
        TODO: 实现 OCR 识别
        """
        # 暂时返回空，后续实现 OCR
        return []

    def recognize_artifact(self, image: np.ndarray, x: int, y: int, w: int, h: int) -> Dict:
        """
        完整识别一个圣遗物
        返回：识别结果字典
        """
        result = {
            "position": (x, y),
            "slot": None,       # 部位
            "set": None,        # 套装
            "main_stat": None,  # 主属性
            "substats": [],     # 副属性
            "star": 0,          # 星级
        }

        try:
            # 裁剪圣遗物区域
            artifact_roi = image[y:y+h, x:x+w]

            # 识别部位
            result["slot"] = self.recognize_slot(artifact_roi)

            # 识别套装
            result["set"] = self.recognize_set(artifact_roi)

            # 识别星级
            result["star"] = self.recognize_star(artifact_roi)

            # 识别主属性（需要详情页截图）
            # result["main_stat"] = self.recognize_stat(detail_roi)

            # 识别副属性（需要详情页截图）
            # result["substats"] = self.recognize_substats(detail_roi)

        except Exception as e:
            print(f"⚠️  识别失败：{e}")

        return result

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自动点击控制模块
负责模拟鼠标点击、滚动等操作
"""

import time
import pyautogui
from typing import Tuple, Optional


class AutoController:
    """自动控制器"""

    def __init__(self, window_rect: Tuple[int, int, int, int], delay: float = 0.3):
        """
        初始化
        window_rect: (left, top, width, height)
        delay: 操作延迟（秒）
        """
        self.window_rect = window_rect
        self.delay = delay
        self.current_pos = None

        # 设置 pyautogui
        pyautogui.FAILSAFE = True  # 鼠标移到屏幕角落可中断
        pyautogui.PAUSE = delay

    def window_to_screen(self, x: int, y: int) -> Tuple[int, int]:
        """窗口坐标转屏幕坐标"""
        left, top, _, _ = self.window_rect
        return (left + x, top + y)

    def move_to(self, x: int, y: int, relative: bool = True):
        """
        移动鼠标
        relative: True=相对窗口坐标，False=绝对屏幕坐标
        """
        if relative:
            screen_x, screen_y = self.window_to_screen(x, y)
        else:
            screen_x, screen_y = x, y

        pyautogui.moveTo(screen_x, screen_y, duration=0.2)
        self.current_pos = (screen_x, screen_y)
        time.sleep(self.delay)

    def click(self, button: str = "left"):
        """点击"""
        pyautogui.click(button=button)
        time.sleep(self.delay)

    def double_click(self):
        """双击"""
        pyautogui.doubleClick()
        time.sleep(self.delay * 2)

    def right_click(self):
        """右键"""
        pyautogui.rightClick()
        time.sleep(self.delay)

    def click_at(self, x: int, y: int, relative: bool = True):
        """移动到指定位置并点击"""
        self.move_to(x, y, relative)
        self.click()

    def scroll(self, clicks: int, x: Optional[int] = None, y: Optional[int] = None):
        """
        滚动
        clicks: 正数=向上，负数=向下
        """
        if x is not None and y is not None:
            self.move_to(x, y)

        pyautogui.scroll(clicks)
        time.sleep(self.delay * 2)

    def wait(self, seconds: float):
        """等待"""
        time.sleep(seconds)

    def click_artifact(self, artifact_x: int, artifact_y: int):
        """
        点击圣遗物查看详情
        artifact_x, artifact_y: 圣遗物在窗口中的坐标
        """
        print(f"   🔍 点击查看详情：({artifact_x}, {artifact_y})")
        self.click_at(artifact_x + 70, artifact_y + 80)  # 点击中心
        self.wait(0.5)  # 等待详情页面打开

    def click_lock_button(self):
        """点击锁定按钮"""
        # 锁定按钮在详情页右下角
        # 需要根据实际位置调整
        print(f"   🔒 点击锁定")
        self.click_at(1430, 920)  # 示例坐标
        self.wait(0.3)

    def close_detail(self):
        """关闭详情页"""
        # 按 ESC 关闭
        pyautogui.press('esc')
        self.wait(0.3)

    def move_to_next_artifact(self, current_x: int, current_y: int, cell_width: int, cell_height: int):
        """
        移动到下一个圣遗物
        从左到右，从上到下
        """
        next_x = current_x + cell_width
        # 如果超出列数，换行
        if next_x > cell_width * 6:  # 原神每行 6 个
            next_x = 0
            next_y = current_y + cell_height
        else:
            next_y = current_y

        self.move_to(next_x, next_y)

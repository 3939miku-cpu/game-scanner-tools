@echo off
chcp 65001 >nul
title 星穹铁道遗器扫描器

echo.
echo ============================================================
echo 🚂 崩坏：星穹铁道 - 遗器自动扫描器
echo ============================================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ 未检测到 Python
    echo 请先安装 Python 3.8+
    pause
    exit /b 1
)

echo ✅ Python 已安装
python --version
echo.

echo 📦 检查依赖...
python -c "import cv2" >nul 2>&1
if %errorlevel% neq 0 (
    echo ⚠️  缺少依赖，正在安装...
    pip install -r requirements.txt
) else (
    echo ✅ 依赖已安装
)

echo.
echo 🚀 启动程序...
echo.

python main.py

echo.
echo ✅ 程序已退出
pause

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
窗口捕获模块
"""

import pygetwindow as gw
import pyautogui
from typing import Optional, Tuple
import time


class WindowCapture:
    """窗口捕获类"""

    def __init__(self, window_title: str = "崩坏：星穹铁道"):
        self.window_title = window_title
        self.window = None
        self.window_rect = None

    def find_window(self) -> bool:
        """查找游戏窗口"""
        try:
            windows = gw.getWindowsWithTitle(self.window_title)
            
            if windows:
                self.window = windows[0]
                self.window_rect = (self.window.left, self.window.top, self.window.width, self.window.height)
                print(f"✅ 找到游戏窗口：{self.window_title}")
                print(f"   位置：{self.window_rect}")
                return True
            
            # 模糊匹配
            all_windows = gw.getAllTitles()
            for title in all_windows:
                if "星穹铁道" in title or "Honkai" in title:
                    self.window = gw.getWindowsWithTitle(title)[0]
                    self.window_rect = (self.window.left, self.window.top, self.window.width, self.window.height)
                    print(f"✅ 找到游戏窗口：{title}")
                    return True
            
            print(f"❌ 未找到游戏窗口：{self.window_title}")
            return False
            
        except Exception as e:
            print(f"❌ 查找窗口失败：{e}")
            return False

    def activate(self) -> bool:
        """激活窗口"""
        if not self.window:
            return False
        
        try:
            if hasattr(self.window, 'activate'):
                self.window.activate()
            time.sleep(0.5)
            print("✅ 窗口已激活")
            return True
        except:
            return True

    def check_resolution(self) -> bool:
        """检查分辨率"""
        if not self.window_rect:
            return False
        
        _, _, width, height = self.window_rect
        if width == 1920 and height == 1080:
            print(f"✅ 分辨率正确：1920x1080")
            return True
        else:
            print(f"⚠️  分辨率不正确：{width}x{height}")
            return False

    def capture(self, region: Optional[Tuple[int, int, int, int]] = None):
        """捕获画面"""
        if not self.window_rect:
            return None
        
        try:
            if region:
                x = self.window_rect[0] + region[0]
                y = self.window_rect[1] + region[1]
                screenshot = pyautogui.screenshot(region=(x, y, region[2], region[3]))
            else:
                x, y, width, height = self.window_rect
                screenshot = pyautogui.screenshot(region=(x, y, width, height))
            
            import cv2
            import numpy as np
            image = np.array(screenshot)
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            return image
            
        except Exception as e:
            print(f"❌ 捕获画面失败：{e}")
            return None

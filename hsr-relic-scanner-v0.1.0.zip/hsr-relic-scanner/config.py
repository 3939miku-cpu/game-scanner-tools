#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置管理模块
"""

import json
from pathlib import Path
from typing import Dict, List, Optional


class Config:
    """配置管理类"""

    DEFAULT_CONFIG = {
        # 目标套装（星穹铁道遗器套装）
        "target_sets": [
            "激奏雷电的乐队",
            "晨昏交界的翔鹰",
            "净庭教宗的圣骑士",
            "野穗伴行的快枪手",
            "繁星璀璨的天才",
            "劫火莲灯铸炼宫",
            "流星追迹的怪盗",
            "风举云飞的勇烈",
        ],
        
        # 目标部位
        "target_slots": ["头", "手", "衣", "鞋"],
        
        # 主属性要求（按部位）
        "slot_main_stats": {
            "头": ["生命值", "防御力", "攻击力"],
            "手": ["攻击力"],
            "衣": ["生命值%", "防御力%", "攻击力%", "治疗量加成", "能量恢复效率"],
            "鞋": ["速度", "攻击力%", "生命值%", "防御力%"],
        },
        
        # 目标副属性
        "target_substats": [
            "暴击率",
            "暴击伤害",
            "攻击力%",
            "速度",
            "能量恢复效率",
        ],
        
        # 最小副属性条数
        "min_substat_count": 3,
        
        # 最小星级
        "min_star": 5,
        
        # 只扫描金色（5 星）
        "only_gold": True,
        
        # 锁定匹配的遗器
        "lock_matching": True,
        
        # 游戏设置
        "game_resolution": "1920x1080",
        "window_title": "崩坏：星穹铁道",
        
        # 扫描延迟（毫秒）
        "scan_delay_ms": 500,
        
        # 网格配置（校准后自动生成）
        "grid": {
            "start_x": 100,
            "start_y": 150,
            "cell_width": 140,
            "cell_height": 160,
            "cols": 6,
            "rows": 4,
        },
    }

    def __init__(self, config_file: Optional[Path] = None):
        if config_file is None:
            config_file = Path(__file__).parent / "config.json"
        
        self.config_file = config_file
        self.config = self.load()

    def load(self) -> Dict:
        """加载配置"""
        if not self.config_file.exists():
            return self.DEFAULT_CONFIG.copy()
        
        try:
            with open(self.config_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"⚠️  加载配置失败：{e}，使用默认配置")
            return self.DEFAULT_CONFIG.copy()

    def save(self):
        """保存配置"""
        with open(self.config_file, "w", encoding="utf-8") as f:
            json.dump(self.config, f, indent=2, ensure_ascii=False)

    def get(self, key: str, default=None):
        """获取配置项"""
        return self.config.get(key, default)

    def set(self, key: str, value):
        """设置配置项"""
        self.config[key] = value
        self.save()

    def get_target_sets(self) -> List[str]:
        """获取目标套装列表"""
        return self.config.get("target_sets", [])

    def get_target_slots(self) -> List[str]:
        """获取目标部位列表"""
        return self.config.get("target_slots", ["头", "手", "衣", "鞋"])

    def get_min_star(self) -> int:
        """获取最小星级"""
        return self.config.get("min_star", 5)

    def should_lock(self) -> bool:
        """是否锁定匹配的遗器"""
        return self.config.get("lock_matching", True)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
图像识别模块 - 模板匹配
"""

import cv2
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class RelicRecognizer:
    """遗器识别类"""

    # 部位名称映射
    SLOT_NAMES = {
        "head": "头",
        "hand": "手",
        "body": "衣",
        "feet": "鞋",
    }

    # 主属性名称映射
    STAT_NAMES = {
        "hp_flat": "生命值",
        "hp_percent": "生命值%",
        "atk_flat": "攻击力",
        "atk_percent": "攻击力%",
        "def_flat": "防御力",
        "def_percent": "防御力%",
        "speed": "速度",
        "crit_rate": "暴击率",
        "crit_dmg": "暴击伤害",
        "effect_hit": "效果命中",
        "effect_res": "效果抵抗",
        "break_effect": "击破特攻",
        "energy_recharge": "能量恢复效率",
        "healing_bonus": "治疗量加成",
        "physical_dmg": "物理属性伤害提高",
        "fire_dmg": "火属性伤害提高",
        "ice_dmg": "冰属性伤害提高",
        "lightning_dmg": "雷属性伤害提高",
        "wind_dmg": "风属性伤害提高",
        "quantum_dmg": "量子属性伤害提高",
        "imaginary_dmg": "虚数属性伤害提高",
    }

    # 套装名称映射（星穹铁道遗器套装）
    SET_NAMES = {
        "thundering_band": "激奏雷电的乐队",
        "eagle_wings": "晨昏交界的翔鹰",
        "palace_court": "净庭教宗的圣骑士",
        "musketeer": "野穗伴行的快枪手",
        "genius_brilliant": "繁星璀璨的天才",
        "flameforge": "劫火莲灯铸炼宫",
        "thief_shooting": "流星追迹的怪盗",
        "champion": "风举云飞的勇烈",
        "guard_wuthering": "戍卫风雪的铁卫",
        "passerby": "过客复往昔",
        "longevous": "长寿面送终",
        "messenger": "信使密函繁缛",
        "band_sizzling": "乐队灼热激昂",
        "wastelander": "废土行者",
        "space_sea": "太空封印站",
        "inert_salsotto": "不老者的仙舟",
        "pan_galactic": "泛银河商业公司",
        "broken_keel": "断绝旧世的孤礁",
        "firmament": "苍穹战线格拉默",
        "iron_cavalry": "铁骑兵团",
    }

    def __init__(self, templates_dir: Optional[Path] = None):
        if templates_dir is None:
            templates_dir = Path(__file__).parent / "templates"

        self.templates_dir = templates_dir
        self.templates = {}
        self.load_templates()

    def load_templates(self):
        """加载模板"""
        print("\n🖼️  正在加载模板...")

        for category in ["slots", "stats", "sets", "ui"]:
            category_dir = self.templates_dir / category
            if category_dir.exists():
                for img_file in category_dir.glob("*.png"):
                    key = img_file.stem
                    template = cv2.imread(str(img_file), cv2.IMREAD_COLOR)
                    if template is not None:
                        self.templates[f"{category}_{key}"] = template
                        print(f"   ✅ {category}: {key}")

        if not self.templates:
            print("⚠️  没有加载到任何模板")

    def match_template(self, image: np.ndarray, template: np.ndarray, threshold: float = 0.8):
        """模板匹配"""
        if template is None:
            return None

        try:
            result = cv2.matchTemplate(image, template, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)

            if max_val >= threshold:
                return (max_loc[0], max_loc[1], max_val)
            return None
        except:
            return None

    def recognize_slot(self, roi: np.ndarray) -> Optional[str]:
        """识别部位"""
        if roi is None or roi.size == 0:
            return None

        best_match = None
        best_score = 0

        for key, template in self.templates.items():
            if not key.startswith("slot_"):
                continue

            result = self.match_template(roi, template, threshold=0.6)
            if result and result[2] > best_score:
                best_score = result[2]
                slot_key = key.replace("slot_", "")
                best_match = self.SLOT_NAMES.get(slot_key, slot_key)

        return best_match

    def recognize_stat(self, roi: np.ndarray) -> Optional[str]:
        """识别主属性"""
        if roi is None or roi.size == 0:
            return None

        best_match = None
        best_score = 0

        for key, template in self.templates.items():
            if not key.startswith("stat_"):
                continue

            result = self.match_template(roi, template, threshold=0.6)
            if result and result[2] > best_score:
                best_score = result[2]
                stat_key = key.replace("stat_", "")
                best_match = self.STAT_NAMES.get(stat_key, stat_key)

        return best_match

    def recognize_set(self, roi: np.ndarray) -> Optional[str]:
        """识别套装"""
        if roi is None or roi.size == 0:
            return None

        best_match = None
        best_score = 0

        for key, template in self.templates.items():
            if not key.startswith("set_"):
                continue

            result = self.match_template(roi, template, threshold=0.6)
            if result and result[2] > best_score:
                best_score = result[2]
                set_key = key.replace("set_", "")
                best_match = self.SET_NAMES.get(set_key, set_key)

        return best_match

    def recognize_star(self, roi: np.ndarray) -> int:
        """识别星级（颜色判断）"""
        if roi is None or roi.size == 0:
            return 0

        try:
            hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)

            # 金色（5 星）
            lower_gold = np.array([20, 100, 150])
            upper_gold = np.array([35, 255, 255])
            mask_gold = cv2.inRange(hsv, lower_gold, upper_gold)
            gold_pixels = cv2.countNonZero(mask_gold)

            # 紫色（4 星）
            lower_purple = np.array([120, 50, 150])
            upper_purple = np.array([150, 255, 255])
            mask_purple = cv2.inRange(hsv, lower_purple, upper_purple)
            purple_pixels = cv2.countNonZero(mask_purple)

            total_pixels = roi.shape[0] * roi.shape[1]
            gold_ratio = gold_pixels / total_pixels
            purple_ratio = purple_pixels / total_pixels

            if gold_ratio > 0.05:
                return 5
            elif purple_ratio > 0.05:
                return 4
            else:
                return 3
        except:
            return 0

    def recognize_relic(self, image: np.ndarray, x: int, y: int, w: int, h: int) -> Dict:
        """完整识别一个遗器"""
        result = {
            "position": (x, y),
            "slot": None,
            "set": None,
            "main_stat": None,
            "substats": [],
            "star": 0,
        }

        try:
            relic_roi = image[y:y+h, x:x+w]
            result["slot"] = self.recognize_slot(relic_roi)
            result["set"] = self.recognize_set(relic_roi)
            result["star"] = self.recognize_star(relic_roi)
        except Exception as e:
            print(f"⚠️  识别失败：{e}")

        return result

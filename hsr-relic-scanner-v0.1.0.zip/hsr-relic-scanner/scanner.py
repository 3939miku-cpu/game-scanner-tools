#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
扫描核心逻辑模块
"""

import time
from datetime import datetime
from pathlib import Path
from typing import Dict

from capture import WindowCapture
from ocr import RelicRecognizer


class RelicScanner:
    """遗器扫描器"""

    def __init__(self, config: Dict):
        self.config = config
        self.capture = WindowCapture(config.get("window_title", "崩坏：星穹铁道"))
        self.recognizer = None
        self.controller = None
        self.scan_results = []
        self.stats = {"total": 0, "matched": 0, "locked": 0, "skipped": 0}

    def run(self):
        """运行扫描"""
        print("\n🚀 启动扫描器...")

        if not self.capture.find_window():
            return
        if not self.capture.activate():
            return
        self.capture.check_resolution()

        templates_dir = Path(__file__).parent / "templates"
        self.recognizer = RelicRecognizer(templates_dir)
        self.controller = AutoController(self.capture.window_rect, delay=0.3)

        self.scan_loop()
        self.generate_report()

    def scan_loop(self):
        """扫描循环"""
        print("\n🔄 开始扫描当前页...")

        grid = self.config.get("grid", {})
        start_x = grid.get("start_x", 100)
        start_y = grid.get("start_y", 150)
        cell_w = grid.get("cell_width", 140)
        cell_h = grid.get("cell_height", 160)
        cols = grid.get("cols", 6)
        rows = grid.get("rows", 4)

        print(f"📐 扫描网格：起点({start_x},{start_y}) 单元格{cell_w}x{cell_h} 网格{cols}x{rows}")

        image = self.capture.capture()
        if image is None:
            print("❌ 无法捕获画面")
            return

        self.scan_results = []

        for row in range(rows):
            for col in range(cols):
                x = start_x + col * cell_w
                y = start_y + row * cell_h
                self.stats["total"] += 1

                result = self.recognizer.recognize_relic(image, x, y, cell_w, cell_h)
                result["position"] = (row, col)
                result["timestamp"] = datetime.now().strftime("%H:%M:%S")

                should_lock = self.should_lock(result)
                result["should_lock"] = should_lock

                if should_lock:
                    self.stats["matched"] += 1
                    print(f"  [{row},{col}] ✅ 匹配 - {result.get('set', '?')} {result.get('slot', '?')} {result.get('star', '?')}星")
                    self.stats["locked"] += 1
                else:
                    self.stats["skipped"] += 1

                self.scan_results.append(result)
                time.sleep(self.config.get("scan_delay_ms", 500) / 1000)

        print(f"\n✅ 扫描完成")
        print(f"   总数：{self.stats['total']}, 匹配：{self.stats['matched']}, 锁定：{self.stats['locked']}, 跳过：{self.stats['skipped']}")
        print(f"\n💡 提示：扫描完一页后，请手动滚动到下一页")

    def should_lock(self, result: Dict) -> bool:
        """判断是否锁定"""
        min_star = self.config.get("min_star", 5)
        if result.get("star", 0) < min_star:
            return False

        if self.config.get("only_gold", True) and result.get("star", 0) < 5:
            return False

        target_sets = self.config.get("target_sets", [])
        if target_sets:
            relic_set = result.get("set")
            if relic_set and relic_set not in target_sets:
                return False

        target_slots = self.config.get("target_slots", [])
        if target_slots and target_slots != ["全部"]:
            slot = result.get("slot")
            if slot and slot not in target_slots:
                return False

        return True

    def generate_report(self):
        """生成报告"""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        reports_dir = Path(__file__).parent / "reports"
        reports_dir.mkdir(exist_ok=True)
        report_path = reports_dir / f"report_{ts}.html"

        html = self.create_html_report()
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"\n📄 报告已生成：{report_path}")

    def create_html_report(self) -> str:
        """创建 HTML 报告"""
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        rows_html = ""
        
        for result in self.scan_results:
            row, col = result.get("position", (0, 0))
            action = "🔒 锁定" if result.get("should_lock") else "⏭️ 跳过"
            action_class = "lock" if result.get("should_lock") else "skip"
            rows_html += f"""<tr><td>{result.get('timestamp','')}</td><td>{row},{col}</td><td>{result.get('set','未知')}</td><td>{result.get('slot','未知')}</td><td>{result.get('star',0)}星</td><td class="{action_class}">{action}</td></tr>"""

        return f"""<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><title>遗器扫描报告 - {ts}</title>
<style>body{{font-family:Arial;margin:20px;background:#1a1a2e;color:#eee}}.container{{max-width:1000px;margin:0 auto}}h1{{color:#a335ee}}.summary{{display:flex;gap:20px;margin:20px 0}}.card{{background:#16213e;padding:20px;border-radius:8px;flex:1;text-align:center}}.card h2{{margin:0;color:#a335ee;font-size:36px}}table{{width:100%;border-collapse:collapse}}th,td{{border:1px solid #333;padding:10px}}th{{background:#16213e;color:#a335ee}}.lock{{color:#52c41a}}.skip{{color:#888}}</style></head>
<body><div class="container"><h1>🚂 星穹铁道遗器扫描报告</h1><p>生成时间：{ts}</p>
<div class="summary"><div class="card"><h2>{self.stats['total']}</h2><p>扫描总数</p></div><div class="card"><h2>{self.stats['matched']}</h2><p>匹配数量</p></div><div class="card"><h2>{self.stats['locked']}</h2><p>已锁定</p></div><div class="card"><h2>{self.stats['skipped']}</h2><p>已跳过</p></div></div>
<h2>📊 扫描结果</h2><table><thead><tr><th>时间</th><th>位置</th><th>套装</th><th>部位</th><th>星级</th><th>操作</th></tr></thead><tbody>{rows_html}</tbody></table></div></body></html>"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自动点击控制模块
"""

import time
import pyautogui
from typing import Tuple, Optional


class AutoController:
    """自动控制器"""

    def __init__(self, window_rect: Tuple[int, int, int, int], delay: float = 0.3):
        self.window_rect = window_rect
        self.delay = delay
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = delay

    def window_to_screen(self, x: int, y: int) -> Tuple[int, int]:
        left, top, _, _ = self.window_rect
        return (left + x, top + y)

    def move_to(self, x: int, y: int, relative: bool = True):
        if relative:
            screen_x, screen_y = self.window_to_screen(x, y)
        else:
            screen_x, screen_y = x, y

        pyautogui.moveTo(screen_x, screen_y, duration=0.2)
        time.sleep(self.delay)

    def click(self, button: str = "left"):
        pyautogui.click(button=button)
        time.sleep(self.delay)

    def click_at(self, x: int, y: int, relative: bool = True):
        self.move_to(x, y, relative)
        self.click()

    def click_relic(self, relic_x: int, relic_y: int):
        """点击遗器查看详情"""
        print(f"   🔍 点击查看详情：({relic_x}, {relic_y})")
        self.click_at(relic_x + 70, relic_y + 80)
        self.wait(0.5)

    def click_lock_button(self):
        """点击锁定按钮"""
        print(f"   🔒 点击锁定")
        self.click_at(1430, 920)
        self.wait(0.3)

    def close_detail(self):
        """关闭详情页"""
        pyautogui.press('esc')
        self.wait(0.3)

    def wait(self, seconds: float):
        time.sleep(seconds)

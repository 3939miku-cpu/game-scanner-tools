#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置管理模块
"""

import json
from pathlib import Path
from typing import List, Dict, Optional


class Config:
    """配置管理类"""

    DEFAULT_CONFIG = {
        "target_sets": [
            "啄木鸟电音",
            "重金属重金属",
            "自由蓝调"
        ],
        "target_substats": [
            "暴击率",
            "暴击伤害",
            "攻击%"
        ],
        "slot_requirements": {
            "4": ["暴击率", "暴击伤害"],
            "5": ["攻击%", "物理伤害%", "冰属性伤害%", "火属性伤害%", "电属性伤害%"],
            "6": ["暴击伤害", "攻击%"]
        },
        "min_substat_count": 3,
        "only_gold": True,
        "game_resolution": "1920x1080",
        "scan_delay_ms": 500,
        "grid": {
            "start_x": 80,
            "start_y": 180,
            "cell_width": 145,
            "cell_height": 165,
            "cols": 8,
            "rows": 4
        }
    }

    def __init__(self, config_file: Optional[Path] = None):
        if config_file is None:
            config_file = Path(__file__).parent / "config.json"

        self.config_file = config_file
        self.config = self.load()

    def load(self) -> Dict:
        """加载配置文件"""
        if self.config_file.exists():
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    config = json.load(f)
                # 合并默认配置
                for key, value in self.DEFAULT_CONFIG.items():
                    if key not in config:
                        config[key] = value
                return config
            except Exception as e:
                print(f"⚠️  加载配置失败：{e}，使用默认配置")
                return self.DEFAULT_CONFIG.copy()
        else:
            print("⚠️  配置文件不存在，使用默认配置")
            return self.DEFAULT_CONFIG.copy()

    def save(self):
        """保存配置文件"""
        with open(self.config_file, "w", encoding="utf-8") as f:
            json.dump(self.config, f, indent=2, ensure_ascii=False)

    def get(self, key: str, default=None):
        """获取配置项"""
        return self.config.get(key, default)

    def set(self, key: str, value):
        """设置配置项"""
        self.config[key] = value
        self.save()

    @property
    def target_sets(self) -> List[str]:
        return self.config.get("target_sets", [])

    @property
    def target_substats(self) -> List[str]:
        return self.config.get("target_substats", [])

    @property
    def slot_requirements(self) -> Dict[str, List[str]]:
        return self.config.get("slot_requirements", {})

    @property
    def grid(self) -> Dict:
        return self.config.get("grid", self.DEFAULT_CONFIG["grid"])

    def __repr__(self):
        return f"Config({self.config_file})"

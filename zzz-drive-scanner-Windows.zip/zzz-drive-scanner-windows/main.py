#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
绝区零驱动盘扫描器 - 主程序入口
"""

import sys
import json
from pathlib import Path

from scanner import DriveDiscScanner
from config import Config
from capture import WindowCapture


def main():
    print("\n" + "=" * 60)
    print("🎮 绝区零驱动盘自动扫描器")
    print("=" * 60)
    print("\n参考：终末地基质扫描器 (endfield-essence-recognizer)")
    print("版本：0.1.0 (开发中)")
    print()

    # 检查配置
    config_file = Path(__file__).parent / "config.json"
    if not config_file.exists():
        print("❌ 配置文件不存在，请创建 config.json")
        print("   参考配置见 config.example.json")
        return

    # 加载配置
    try:
        with open(config_file, "r", encoding="utf-8") as f:
            config = json.load(f)
        print("✅ 配置已加载")
    except Exception as e:
        print(f"❌ 加载配置失败：{e}")
        return

    # 检查模板目录
    templates_dir = Path(__file__).parent / "templates"
    if not templates_dir.exists():
        print(f"⚠️  模板目录不存在：{templates_dir}")
        print("   请准备模板图片后重试")
        create_templates = input("   是否创建空模板目录？(y/n): ").strip().lower()
        if create_templates == "y":
            templates_dir.mkdir(parents=True)
            (templates_dir / "stats").mkdir(exist_ok=True)
            (templates_dir / "sets").mkdir(exist_ok=True)
            (templates_dir / "ui").mkdir(exist_ok=True)
            print("✅ 模板目录已创建")
            print("   请将模板图片放入对应子目录")
        return

    # 显示配置
    print("\n📋 当前配置:")
    print(f"   目标套装：{', '.join(config.get('target_sets', []))}")
    print(f"   目标副属性：{', '.join(config.get('target_substats', []))}")
    print(f"   只扫描金色：{config.get('only_gold', True)}")
    print()

    # 选择模式
    print("请选择模式:")
    print("  1. 扫描背包")
    print("  2. 校准模式（设置网格坐标）")
    print("  3. 模板测试（测试模板匹配）")
    print("  4. 退出")
    print()

    choice = input("输入选项 (1/2/3/4): ").strip()

    if choice == "1":
        run_scanner(config)
    elif choice == "2":
        run_calibration(config)
    elif choice == "3":
        run_template_test()
    elif choice == "4":
        print("👋 再见!")
    else:
        print("❌ 无效选项")


def run_scanner(config):
    """运行扫描器"""
    print("\n" + "=" * 60)
    print("🎒 开始扫描驱动盘")
    print("=" * 60)
    print("\n⚠️  请确保:")
    print("  1. 绝区零已打开且为 1920x1080 窗口模式")
    print("  2. 已进入背包 - 驱动盘页面")
    print("  3. 扫描过程中不要操作游戏")
    print()

    input("按回车开始扫描...")

    try:
        scanner = DriveDiscScanner(config)
        scanner.run()
        print("\n✅ 扫描完成!")
    except KeyboardInterrupt:
        print("\n👋 用户中断")
    except Exception as e:
        print(f"\n❌ 扫描失败：{e}")
        import traceback
        traceback.print_exc()


def run_calibration(config):
    """运行校准"""
    print("\n" + "=" * 60)
    print("🎯 校准模式")
    print("=" * 60)
    print("\n请将游戏窗口设置为 1920x1080 窗口模式")
    print("然后进入背包 - 驱动盘页面")
    print()

    input("按回车开始校准...")

    try:
        capture = WindowCapture()
        if not capture.find_window():
            print("❌ 找不到游戏窗口")
            return

        capture.activate()

        print("\n请将鼠标移动到第一个驱动盘的左上角，然后按回车...")
        input()

        import pyautogui
        pos1 = pyautogui.position()
        print(f"位置 1: {pos1}")

        print("请将鼠标移动到第二个驱动盘的左上角，然后按回车...")
        input()

        pos2 = pyautogui.position()
        print(f"位置 2: {pos2}")

        # 计算网格
        cell_width = pos2[0] - pos1[0]
        cell_height = pos2[1] - pos1[1]

        print(f"\n✅ 计算结果:")
        print(f"   起始位置：({pos1[0]}, {pos1[1]})")
        print(f"   单元格大小：{cell_width} x {cell_height}")

        # 更新配置
        config["grid"] = {
            "start_x": pos1[0] - capture.window_rect[0],
            "start_y": pos1[1] - capture.window_rect[1],
            "cell_width": cell_width,
            "cell_height": cell_height,
            "cols": 8,
            "rows": 4
        }

        config_file = Path(__file__).parent / "config.json"
        with open(config_file, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2, ensure_ascii=False)

        print(f"\n✅ 配置已保存到 {config_file}")

    except Exception as e:
        print(f"\n❌ 校准失败：{e}")
        import traceback
        traceback.print_exc()


def run_template_test():
    """测试模板匹配"""
    print("\n" + "=" * 60)
    print("🖼️  模板测试")
    print("=" * 60)
    print("\n此功能用于测试模板匹配是否准确")
    print("需要准备好模板图片")
    print()
    print("⚠️  此功能开发中...")


if __name__ == "__main__":
    main()

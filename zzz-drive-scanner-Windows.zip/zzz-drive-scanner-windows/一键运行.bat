@echo off
chcp 65001 >nul
title 绝区零驱动盘扫描器

echo.
echo ============================================================
echo 🎮 绝区零驱动盘自动扫描器
echo ============================================================
echo.

REM 检查 Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ 未检测到 Python
    echo.
    echo 请先安装 Python 3.8+：https://www.python.org/downloads/
    echo 安装时勾选 "Add Python to PATH"
    echo.
    pause
    exit /b 1
)

echo ✅ Python 已安装
python --version
echo.

REM 检查依赖
echo 📦 检查依赖...
python -c "import cv2" >nul 2>&1
if %errorlevel% neq 0 (
    echo ⚠️  缺少依赖，正在安装...
    pip install -r requirements.txt
    if %errorlevel% neq 0 (
        echo.
        echo ❌ 安装失败，请手动运行：pip install -r requirements.txt
        pause
        exit /b 1
    )
) else (
    echo ✅ 依赖已安装
)

echo.
echo ============================================================
echo 🚀 启动程序
echo ============================================================
echo.

REM 运行主程序
python main.py

echo.
echo ============================================================
echo ✅ 程序已退出
echo ============================================================
echo.
pause

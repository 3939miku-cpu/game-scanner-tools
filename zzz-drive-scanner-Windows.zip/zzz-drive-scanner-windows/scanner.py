#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
扫描核心逻辑模块
"""

import time
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from capture import WindowCapture
from ocr import DriveDiscRecognizer
from auto_control import AutoController
from config import Config


class DriveDiscScanner:
    """驱动盘扫描器"""

    def __init__(self, config: Dict):
        self.config = config
        self.capture = WindowCapture()
        self.recognizer = None
        self.controller = None

        self.scan_results = []
        self.stats = {
            "total": 0,
            "matched": 0,
            "locked": 0,
            "skipped": 0,
        }

    def run(self):
        """运行扫描"""
        print("\n🚀 启动扫描器...")

        # 1. 查找窗口
        if not self.capture.find_window():
            return

        # 2. 激活窗口
        if not self.capture.activate():
            return

        # 3. 检查分辨率
        self.capture.check_resolution()

        # 4. 初始化识别器和控制器
        templates_dir = Path(__file__).parent / "templates"
        self.recognizer = DriveDiscRecognizer(templates_dir)
        self.controller = AutoController(self.capture.window_rect, delay=0.3)

        # 5. 开始扫描
        self.scan_loop()

        # 6. 生成报告
        self.generate_report()

    def scan_loop(self):
        """扫描循环"""
        print("\n🔄 开始扫描循环...")

        grid = self.config.get("grid", {})
        start_x = grid.get("start_x", 80)
        start_y = grid.get("start_y", 180)
        cell_w = grid.get("cell_width", 145)
        cell_h = grid.get("cell_height", 165)
        cols = grid.get("cols", 8)
        rows = grid.get("rows", 4)

        print(f"📐 扫描网格：起点({start_x},{start_y}) 单元格{cell_w}x{cell_h} 网格{cols}x{rows}")

        # 捕获画面
        image = self.capture.capture()
        if image is None:
            print("❌ 无法捕获画面")
            return

        self.scan_results = []

        # 遍历网格
        for row in range(rows):
            for col in range(cols):
                x = start_x + col * cell_w
                y = start_y + row * cell_h

                self.stats["total"] += 1

                # 识别驱动盘
                result = self.recognizer.recognize_drive_disc(image, x, y, cell_w, cell_h)
                result["position"] = (row, col)
                result["timestamp"] = datetime.now().strftime("%H:%M:%S")

                # 判断是否匹配
                should_lock = self.should_lock(result)
                result["should_lock"] = should_lock

                if should_lock:
                    self.stats["matched"] += 1
                    print(f"  [{row},{col}] ✅ 匹配 - {result.get('set', '?')} {result.get('stat', '?')}")

                    # 点击查看详情
                    self.controller.click_detail(x, y)

                    # 识别副属性并确认
                    # TODO: 需要详情页截图和 OCR 识别
                    # detail_image = self.capture.capture()
                    # substats = self.recognizer.recognize_substats_from_detail(detail_image)
                    
                    # 检查副属性是否符合要求
                    # if self.check_substats(substats):
                    
                    # 点击锁定
                    self.controller.click_lock_button(None)  # TODO: 传入锁定按钮位置
                    self.stats["locked"] += 1
                    print(f"      🔒 已锁定")

                    # 关闭详情
                    self.controller.close_detail()
                else:
                    self.stats["skipped"] += 1
                    print(f"  [{row},{col}] ⏭️ 跳过 - {result.get('set', '?')} {result.get('stat', '?')}")

                self.scan_results.append(result)

                # 延迟
                time.sleep(self.config.get("scan_delay_ms", 500) / 1000)

        print(f"\n✅ 扫描完成")
        print(f"   总数：{self.stats['total']}")
        print(f"   匹配：{self.stats['matched']}")
        print(f"   锁定：{self.stats['locked']}")
        print(f"   跳过：{self.stats['skipped']}")

    def should_lock(self, result: Dict) -> bool:
        """判断是否应该锁定"""
        # 只扫描金色
        if self.config.get("only_gold", True):
            if not result.get("is_gold", False):
                return False

        # 检查套装
        target_sets = self.config.get("target_sets", [])
        if target_sets:
            disc_set = result.get("set")
            if disc_set and disc_set not in target_sets:
                return False

        # 检查主属性（456 号位）
        # TODO: 根据号位检查

        # 检查副属性
        # TODO: OCR 识别后检查

        return True

    def generate_report(self):
        """生成扫描报告"""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        reports_dir = Path(__file__).parent / "reports"
        reports_dir.mkdir(exist_ok=True)

        report_path = reports_dir / f"report_{ts}.html"

        # 生成 HTML
        html = self.create_html_report()

        with open(report_path, "w", encoding="utf-8") as f:
            f.write(html)

        print(f"\n📄 报告已生成：{report_path}")

        # 自动打开
        import webbrowser
        webbrowser.open(str(report_path))

    def create_html_report(self) -> str:
        """创建 HTML 报告"""
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        rows_html = ""
        for result in self.scan_results:
            row, col = result.get("position", (0, 0))
            action = "🔒 锁定" if result.get("should_lock") else "⏭️ 跳过"
            action_class = "lock" if result.get("should_lock") else "skip"

            rows_html += f"""<tr>
                <td>{result.get('timestamp', '')}</td>
                <td>{row},{col}</td>
                <td>{result.get('set', '未知')}</td>
                <td>{result.get('stat', '未知')}</td>
                <td class="{action_class}">{action}</td>
            </tr>"""

        html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>驱动盘扫描报告 - {ts}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #1a1a2e; color: #eee; }}
        .container {{ max-width: 1000px; margin: 0 auto; }}
        h1 {{ color: #ff6b00; }}
        .summary {{ display: flex; gap: 20px; margin: 20px 0; }}
        .card {{ background: #16213e; padding: 20px; border-radius: 8px; flex: 1; text-align: center; }}
        .card h2 {{ margin: 0; color: #ff6b00; font-size: 36px; }}
        .card p {{ margin: 5px 0 0; color: #888; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 20px; }}
        th, td {{ border: 1px solid #333; padding: 10px; text-align: left; }}
        th {{ background: #16213e; color: #ff6b00; }}
        tr:nth-child(even) {{ background: #0f0f23; }}
        .lock {{ color: #52c41a; }}
        .skip {{ color: #888; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🎮 绝区零驱动盘扫描报告</h1>
        <p>生成时间：{ts}</p>

        <div class="summary">
            <div class="card">
                <h2>{self.stats['total']}</h2>
                <p>扫描总数</p>
            </div>
            <div class="card">
                <h2>{self.stats['matched']}</h2>
                <p>匹配数量</p>
            </div>
            <div class="card">
                <h2>{self.stats['locked']}</h2>
                <p>已锁定</p>
            </div>
            <div class="card">
                <h2>{self.stats['skipped']}</h2>
                <p>已跳过</p>
            </div>
        </div>

        <h2>📊 扫描结果</h2>
        <table>
            <thead>
                <tr>
                    <th>时间</th>
                    <th>位置</th>
                    <th>套装</th>
                    <th>主属性</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                {rows_html}
            </tbody>
        </table>
    </div>
</body>
</html>"""

        return html

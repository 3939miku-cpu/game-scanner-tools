#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
窗口捕获模块
负责查找、激活、捕获游戏窗口
"""

import time
from typing import Optional, Tuple

try:
    import pygetwindow as gw
    import pyautogui
    from PIL import Image
    import cv2
    import numpy as np
except ImportError as e:
    print(f"❌ 缺少依赖：{e}")
    print("请运行：pip install opencv-python pyautogui pygetwindow pillow")
    exit(1)


class WindowCapture:
    """窗口捕获类"""

    def __init__(self, window_title: str = "绝区零"):
        self.window_title = window_title
        self.window = None
        self.window_rect = None  # (left, top, width, height)

    def find_window(self) -> bool:
        """查找游戏窗口"""
        print(f"\n🔍 正在查找窗口：「{self.window_title}」...")

        # 关键词匹配
        keywords = [self.window_title, "Zenless", "ZZZ", "绝区零"]

        all_windows = gw.getAllTitles()
        print(f"📋 当前打开窗口：{len(all_windows)} 个")

        for title in all_windows:
            for keyword in keywords:
                if keyword.lower() in title.lower():
                    print(f"✅ 找到匹配窗口：「{title}」")
                    windows = gw.getWindowsWithTitle(title)
                    if windows:
                        self.window = windows[0]
                        self.window_rect = (
                            self.window.left,
                            self.window.top,
                            self.window.width,
                            self.window.height
                        )
                        print(f"📐 窗口信息:")
                        print(f"   位置：({self.window.left}, {self.window.top})")
                        print(f"   大小：{self.window.width} x {self.window.height}")
                        return True

        print("❌ 未找到游戏窗口")
        print("\n💡 提示:")
        print("  1. 确保绝区零已打开")
        print("  2. 确保是窗口模式（不是全屏）")
        print("  3. 窗口标题包含「绝区零」或「Zenless」")
        return False

    def activate(self) -> bool:
        """激活窗口到前台"""
        if not self.window:
            print("❌ 窗口未找到")
            return False

        try:
            print("\n📐 正在激活窗口...")

            # 如果最小化，先还原
            if self.window.isMinimized:
                print("   窗口最小化，正在还原...")
                self.window.restore()
                time.sleep(0.5)

            # 激活窗口
            if not self.window.isActive:
                self.window.activate()
                time.sleep(0.5)

            # 更新窗口矩形
            self.window_rect = (
                self.window.left,
                self.window.top,
                self.window.width,
                self.window.height
            )

            print(f"✅ 窗口已激活")
            print(f"   位置：({self.window.left}, {self.window.top})")
            print(f"   大小：{self.window.width} x {self.window.height}")

            return True

        except Exception as e:
            print(f"❌ 激活失败：{e}")
            return False

    def capture(self) -> Optional[np.ndarray]:
        """捕获窗口画面"""
        if not self.window_rect:
            print("❌ 窗口矩形未设置")
            return None

        try:
            x, y, w, h = self.window_rect

            # 截图
            screenshot = pyautogui.screenshot(region=(int(x), int(y), int(w), int(h)))

            # 转换为 OpenCV 格式 (BGR)
            image = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)

            return image

        except Exception as e:
            print(f"❌ 捕获失败：{e}")
            return None

    def capture_and_save(self, filepath: str) -> bool:
        """捕获窗口并保存"""
        image = self.capture()
        if image is None:
            return False

        try:
            cv2.imwrite(filepath, image)
            print(f"✅ 截图已保存：{filepath}")
            return True
        except Exception as e:
            print(f"❌ 保存失败：{e}")
            return False

    def check_resolution(self) -> bool:
        """检查分辨率是否为 1920x1080"""
        if not self.window_rect:
            return False

        w, h = self.window_rect[2], self.window_rect[3]
        if w == 1920 and h == 1080:
            print(f"✅ 分辨率正确：1920x1080")
            return True
        else:
            print(f"⚠️  分辨率不正确：{w}x{h}")
            print("   建议设置为 1920x1080 窗口模式")
            return False

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
绝区零驱动盘图标裁剪工具 - Windows 本地版
在 Windows 上运行，自动从截图裁剪套装图标
"""

import os
import sys
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print("❌ 缺少 Pillow 库")
    print("请运行：pip install Pillow")
    input("按回车退出...")
    sys.exit(1)


# 8 张截图与套装名称映射
SCREENSHOTS = [
    ("zzz_1.png", "woodpecker", "啄木鸟电音"),
    ("zzz_2.png", "blues", "自由蓝调"),
    ("zzz_3.png", "swing", "摇摆爵士"),
    ("zzz_4.png", "hormone", "激素朋克"),
    ("zzz_5.png", "thunderstorm", "雷暴重金属"),
    ("zzz_6.png", "moonlight", "折枝剑歌"),
    ("zzz_7.png", "flowing_light", "流光咏叹"),
    ("zzz_8.png", "waves", "沧浪行歌"),
]

# 图标区域（1920x1080 分辨率）
# 根据截图分析：套装图标在详情面板右上角
SET_ICON = {"x": 1480, "y": 260, "w": 140, "h": 140}
# 锁定按钮在右下角
LOCK_BUTTON = {"x": 1430, "y": 920, "w": 50, "h": 50}
# 主属性图标（心形/剑形等）
STAT_ICON = {"x": 1360, "y": 440, "w": 40, "h": 40}


def crop_region(img, region, output_path):
    """裁剪区域并保存"""
    width, height = img.size
    
    # 计算缩放比例
    scale_x = width / 1920
    scale_y = height / 1080
    
    x = int(region["x"] * scale_x)
    y = int(region["y"] * scale_y)
    w = int(region["w"] * scale_x)
    h = int(region["h"] * scale_y)
    
    icon = img.crop((x, y, x + w, y + h))
    icon.save(output_path, "PNG")
    return output_path


def main():
    print("\n" + "=" * 60)
    print("🎮 绝区零 - 驱动盘图标批量裁剪工具")
    print("=" * 60)
    
    # 查找截图目录
    screenshots_dir = Path(__file__).parent / "screenshots"
    templates_dir = Path(__file__).parent / "templates"
    sets_dir = templates_dir / "sets"
    ui_dir = templates_dir / "ui"
    
    # 创建输出目录
    sets_dir.mkdir(parents=True, exist_ok=True)
    ui_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"\n📂 截图目录：{screenshots_dir}")
    print(f"📂 输出目录：{sets_dir}")
    print()
    
    processed = 0
    failed = 0
    
    for filename, set_key, set_name in SCREENSHOTS:
        screenshot_path = screenshots_dir / filename
        
        if not screenshot_path.exists():
            print(f"⚠️  跳过：{filename} → {set_name} (文件不存在)")
            failed += 1
            continue
        
        try:
            img = Image.open(screenshot_path)
            print(f"📸 处理：{set_name} ({filename})")
            
            # 裁剪套装图标
            set_output = sets_dir / f"{set_key}.png"
            crop_region(img, SET_ICON, set_output)
            print(f"   ✅ 套装图标：{set_key}.png")
            
            processed += 1
            
        except Exception as e:
            print(f"   ❌ 失败：{e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"✅ 完成！成功：{processed} 个，失败：{failed} 个")
    
    if processed > 0:
        print(f"\n📁 套装图标已保存到：{sets_dir}")
        print("\n生成的文件:")
        for f in sorted(sets_dir.glob("*.png")):
            print(f"   - {f.name}")
    
    print("\n按回车退出...")
    input()


if __name__ == "__main__":
    main()

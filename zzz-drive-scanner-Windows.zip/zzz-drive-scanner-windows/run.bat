@echo off
chcp 65001 >nul
echo ============================================
echo 🎮 绝区零驱动盘扫描器
echo ============================================
echo.
echo 版本：0.1.0 (开发中)
echo.

REM 检查 Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ 未检测到 Python
    echo.
    echo 请访问：https://www.python.org/downloads/
    echo 下载并安装 Python 3.10+
    echo 安装时勾选 "Add Python to PATH"
    echo.
    pause
    start https://www.python.org/downloads/
    exit /b 1
)

echo ✅ Python 已安装
python --version
echo.

REM 检查依赖
python -c "import cv2" >nul 2>&1
if errorlevel 1 (
    echo 📦 正在安装依赖库...
    pip install opencv-python pyautogui pygetwindow numpy keyboard Pillow
    echo.
)

echo 🚀 启动扫描器...
echo.
python main.py

echo.
pause

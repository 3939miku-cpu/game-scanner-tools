@echo off
chcp 65001 >nul
title 安装依赖

echo.
echo ============================================================
echo 📦 绝区零驱动盘扫描器 - 依赖安装
echo ============================================================
echo.

REM 检查 Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ 未检测到 Python
    echo.
    echo 请先安装 Python 3.8+：https://www.python.org/downloads/
    echo 安装时勾选 "Add Python to PATH"
    echo.
    pause
    exit /b 1
)

echo ✅ Python 已安装
python --version
echo.

echo 📥 正在安装依赖...
echo.

pip install -r requirements.txt

if %errorlevel% neq 0 (
    echo.
    echo ❌ 安装失败
    echo.
    echo 请尝试手动安装：
    echo   pip install opencv-python pyautogui pygetwindow numpy keyboard Pillow
    echo.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo ✅ 依赖安装完成！
echo ============================================================
echo.
echo 现在可以运行 "一键运行.bat" 启动程序
echo.
pause

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
图像识别模块 - 模板匹配
负责识别驱动盘的主属性、套装、副属性等
"""

import cv2
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class DriveDiscRecognizer:
    """驱动盘识别类"""

    # 主属性映射
    STAT_NAMES = {
        "atk": "攻击",
        "hp": "生命",
        "def": "防御",
        "crit_rate": "暴击率",
        "crit_dmg": "暴击伤害",
        "pen": "穿透率",
        "anomaly": "异常掌控",
        "energy": "能量恢复",
        "physical_dmg": "物理伤害",
        "fire_dmg": "火属性伤害",
        "ice_dmg": "冰属性伤害",
        "electric_dmg": "电属性伤害",
    }

    # 套装名称映射（根据用户截图更新）
    SET_NAMES = {
        "woodpecker": "啄木鸟电音",
        "blues": "自由蓝调",
        "swing": "摇摆爵士",
        "hormone": "激素朋克",
        "thunderstorm": "雷暴重金属",
        "moonlight": "折枝剑歌",
        "flowing_light": "流光咏叹",
        "waves": "沧浪行歌",
    }

    def __init__(self, templates_dir: Optional[Path] = None):
        if templates_dir is None:
            templates_dir = Path(__file__).parent / "templates"

        self.templates_dir = templates_dir
        self.templates = {}
        self.load_templates()

    def load_templates(self):
        """加载模板图片"""
        print("\n🖼️  正在加载模板...")

        # 加载主属性模板
        stats_dir = self.templates_dir / "stats"
        if stats_dir.exists():
            for img_file in stats_dir.glob("*.png"):
                key = img_file.stem
                template = cv2.imread(str(img_file), cv2.IMREAD_COLOR)
                if template is not None:
                    self.templates[f"stat_{key}"] = template
                    print(f"   ✅ 主属性模板：{key}")

        # 加载套装模板
        sets_dir = self.templates_dir / "sets"
        if sets_dir.exists():
            for img_file in sets_dir.glob("*.png"):
                key = img_file.stem
                template = cv2.imread(str(img_file), cv2.IMREAD_COLOR)
                if template is not None:
                    self.templates[f"set_{key}"] = template
                    print(f"   ✅ 套装模板：{key}")

        # 加载 UI 模板
        ui_dir = self.templates_dir / "ui"
        if ui_dir.exists():
            for img_file in ui_dir.glob("*.png"):
                key = img_file.stem
                template = cv2.imread(str(img_file), cv2.IMREAD_COLOR)
                if template is not None:
                    self.templates[f"ui_{key}"] = template
                    print(f"   ✅ UI 模板：{key}")

        if not self.templates:
            print("⚠️  没有加载到任何模板")
            print("   请将模板图片放入 templates/ 目录")

    def match_template(self, image: np.ndarray, template: np.ndarray, threshold: float = 0.8) -> Optional[Tuple[int, int, float]]:
        """
        模板匹配
        返回：(x, y, confidence) 或 None
        """
        if template is None:
            return None

        try:
            result = cv2.matchTemplate(image, template, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)

            if max_val >= threshold:
                return (max_loc[0], max_loc[1], max_val)

            return None

        except Exception as e:
            return None

    def recognize_stat(self, roi: np.ndarray) -> Optional[str]:
        """
        识别主属性
        roi: 驱动盘图标区域
        返回：属性名称（中文）
        """
        if roi is None or roi.size == 0:
            return None

        best_match = None
        best_score = 0

        for key, template in self.templates.items():
            if not key.startswith("stat_"):
                continue

            result = self.match_template(roi, template, threshold=0.6)
            if result and result[2] > best_score:
                best_score = result[2]
                stat_key = key.replace("stat_", "")
                best_match = self.STAT_NAMES.get(stat_key, stat_key)

        return best_match

    def recognize_set(self, roi: np.ndarray) -> Optional[str]:
        """
        识别套装
        roi: 驱动盘图标区域
        返回：套装名称（中文）
        """
        if roi is None or roi.size == 0:
            return None

        best_match = None
        best_score = 0

        for key, template in self.templates.items():
            if not key.startswith("set_"):
                continue

            result = self.match_template(roi, template, threshold=0.6)
            if result and result[2] > best_score:
                best_score = result[2]
                set_key = key.replace("set_", "")
                best_match = self.SET_NAMES.get(set_key, set_key)

        return best_match

    def is_gold(self, roi: np.ndarray) -> bool:
        """
        判断是否为金色边框（S 级）
        通过颜色分析
        """
        if roi is None or roi.size == 0:
            return False

        try:
            # 转换为 HSV 颜色空间
            hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)

            # 金色范围（大致）
            # H: 20-35, S: 100-255, V: 150-255
            lower_gold = np.array([20, 100, 150])
            upper_gold = np.array([35, 255, 255])

            mask = cv2.inRange(hsv, lower_gold, upper_gold)
            gold_pixels = cv2.countNonZero(mask)

            # 金色像素比例
            ratio = gold_pixels / (roi.shape[0] * roi.shape[1])

            return ratio > 0.05  # 金色像素超过 5%

        except Exception as e:
            return False

    def recognize_substats(self, roi: np.ndarray) -> List[str]:
        """
        识别副属性
        需要 OCR，暂时返回空列表
        TODO: 实现 OCR 识别
        """
        # 暂时返回空，后续实现 OCR
        return []

    def recognize_drive_disc(self, image: np.ndarray, x: int, y: int, w: int, h: int) -> Dict:
        """
        完整识别一个驱动盘
        返回：识别结果字典
        """
        result = {
            "position": (x, y),
            "stat": None,
            "set": None,
            "is_gold": False,
            "substats": [],
            "slot": None,
        }

        try:
            # 裁剪驱动盘区域
            disc_roi = image[y:y+h, x:x+w]

            # 识别主属性
            result["stat"] = self.recognize_stat(disc_roi)

            # 识别套装
            result["set"] = self.recognize_set(disc_roi)

            # 判断是否金色
            result["is_gold"] = self.is_gold(disc_roi)

            # 识别副属性（需要详情页截图）
            # result["substats"] = self.recognize_substats(detail_roi)

        except Exception as e:
            print(f"⚠️  识别失败：{e}")

        return result

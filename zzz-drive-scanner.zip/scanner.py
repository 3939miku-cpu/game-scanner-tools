#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
绝区零驱动盘自动扫描工具
自动识别并锁定符合推荐属性的驱动盘
"""

import json
import time
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional, Tuple

try:
    import cv2
    import numpy as np
    import pyautogui
    import pygetwindow as gw
    from PIL import Image
except ImportError as e:
    print(f"❌ 缺少依赖库：{e}")
    print("请运行：pip install opencv-python numpy pyautogui pygetwindow pillow")
    exit(1)


# 配置日志
log_dir = Path(__file__).parent / "logs"
log_dir.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_dir / f"scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class DriveDiscScanner:
    """驱动盘扫描器"""
    
    # 驱动盘属性映射（图标识别用）
    STAT_ICONS = {
        "攻击": "atk",
        "生命": "hp", 
        "防御": "def",
        "暴击": "crit_rate",
        "暴击伤害": "crit_dmg",
        "穿透": "pen",
        "异常掌控": "anomaly",
        "能量恢复": "energy",
    }
    
    # 套装颜色映射（简化版）
    SET_COLORS = {
        "雷暴": (150, 100, 255),
        "摇摆": (255, 200, 100),
        "啄木鸟": (100, 255, 150),
        "重金属": (200, 200, 200),
        "自由蓝调": (100, 150, 255),
        "河豚电音": (255, 100, 200),
        "激素朋克": (255, 50, 50),
        "建桥人": (150, 200, 100),
    }
    
    def __init__(self):
        self.base_dir = Path(__file__).parent
        self.templates_dir = self.base_dir / "templates"
        self.reports_dir = self.base_dir / "reports"
        self.config_file = self.base_dir / "config.json"
        
        self.reports_dir.mkdir(exist_ok=True)
        self.templates_dir.mkdir(exist_ok=True)
        
        # 加载配置
        self.config = self.load_config()
        
        # 游戏窗口设置
        self.window = None
        self.window_rect = None
        
        # 扫描结果
        self.scan_results = []
        
        logger.info("🎮 驱动盘扫描器初始化完成")
    
    def load_config(self) -> Dict:
        """加载配置文件"""
        default_config = {
            "characters": {
                "安比": {
                    "推荐属性": ["攻击", "暴击", "暴击伤害", "穿透"],
                    "推荐套装": ["雷暴", "摇摆", "啄木鸟"]
                },
                "比利": {
                    "推荐属性": ["攻击", "暴击", "暴击伤害"],
                    "推荐套装": ["啄木鸟", "摇摆"]
                },
                "妮可": {
                    "推荐属性": ["攻击", "能量恢复", "穿透"],
                    "推荐套装": ["自由蓝调", "河豚电音"]
                },
                "猫又": {
                    "推荐属性": ["攻击", "暴击", "暴击伤害"],
                    "推荐套装": ["啄木鸟", "重金属"]
                }
            },
            "min_star": 4,
            "lock_matching": True,
            "scan_delay": 0.5,
            "window_title": "绝区零"
        }
        
        if self.config_file.exists():
            with open(self.config_file, "r", encoding="utf-8") as f:
                config = json.load(f)
                # 合并配置
                for key, value in default_config.items():
                    if key not in config:
                        config[key] = value
                return config
        else:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(default_config, f, indent=2, ensure_ascii=False)
            logger.info("📝 已创建默认配置文件")
            return default_config
    
    def find_game_window(self) -> Optional[gw.Window]:
        """查找游戏窗口"""
        title_keywords = ["绝区零", "Zenless", "ZZZ"]
        
        windows = gw.getWindowsWithTitle("")
        for w in windows:
            for keyword in title_keywords:
                if keyword.lower() in w.title.lower():
                    logger.info(f"✅ 找到游戏窗口：{w.title}")
                    return w
        
        logger.warning("⚠️ 未找到游戏窗口，请确保游戏已打开且为窗口模式")
        return None
    
    def activate_window(self):
        """激活游戏窗口"""
        if self.window:
            try:
                self.window.activate()
                time.sleep(0.5)
                self.window_rect = self.window.left, self.window.top, self.window.width, self.window.height
                logger.info(f"📐 窗口位置：{self.window_rect}")
                return True
            except Exception as e:
                logger.error(f"❌ 激活窗口失败：{e}")
        return False
    
    def capture_window(self) -> Optional[np.ndarray]:
        """捕获游戏窗口画面"""
        if not self.window_rect:
            return None
        
        try:
            x, y, w, h = self.window_rect
            screenshot = pyautogui.screenshot(region=(x, y, w, h))
            image = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
            return image
        except Exception as e:
            logger.error(f"❌ 捕获窗口失败：{e}")
            return None
    
    def detect_drive_disc(self, image: np.ndarray, x: int, y: int, w: int, h: int) -> Optional[Dict]:
        """识别单个驱动盘"""
        try:
            # 裁剪驱动盘区域
            disc_roi = image[y:y+h, x:x+w]
            
            # 检测星级（通过颜色/亮度）
            star = self.detect_star(disc_roi)
            
            # 检测主属性（通过图标匹配）
            stat = self.detect_stat(disc_roi)
            
            # 检测套装（通过颜色分析）
            set_name = self.detect_set(disc_roi)
            
            if star and stat:
                return {
                    "star": star,
                    "stat": stat,
                    "set": set_name or "未知",
                    "position": (x, y),
                    "timestamp": datetime.now().strftime("%H:%M:%S")
                }
        except Exception as e:
            logger.debug(f"识别失败：{e}")
        
        return None
    
    def detect_star(self, roi: np.ndarray) -> Optional[int]:
        """检测驱动盘星级"""
        # 简化版：通过整体亮度/颜色判断
        # 5 星通常是金色/橙色，4 星是紫色，3 星是蓝色
        avg_color = cv2.mean(roi)[:3]
        
        # 简单判断（实际需要更精确的模板匹配）
        if avg_color[2] > 180 and avg_color[1] > 100:  # 偏橙/金
            return 5
        elif avg_color[0] > 150 and avg_color[2] > 150:  # 偏紫
            return 4
        elif avg_color[0] > 150 and avg_color[2] < 100:  # 偏蓝
            return 3
        
        return None
    
    def detect_stat(self, roi: np.ndarray) -> Optional[str]:
        """检测主属性"""
        # 实际应该用模板匹配属性图标
        # 这里简化处理，返回None表示需要手动校准
        return None
    
    def detect_set(self, roi: np.ndarray) -> Optional[str]:
        """检测套装类型"""
        # 分析颜色特征
        avg_color = cv2.mean(roi)[:3]
        
        best_match = None
        best_dist = float('inf')
        
        for set_name, color in self.SET_COLORS.items():
            dist = np.sqrt(sum((a - b) ** 2 for a, b in zip(avg_color, color)))
            if dist < best_dist:
                best_dist = dist
                best_match = set_name
        
        if best_dist < 80:  # 阈值
            return best_match
        return None
    
    def is_worth_locking(self, disc: Dict) -> Tuple[bool, str]:
        """判断是否值得锁定"""
        star = disc.get("star", 0)
        stat = disc.get("stat", "")
        set_name = disc.get("set", "")
        
        # 检查星级
        if star < self.config.get("min_star", 4):
            return False, "星级不足"
        
        # 检查属性匹配
        for char_name, char_config in self.config.get("characters", {}).items():
            recommended_stats = char_config.get("推荐属性", [])
            recommended_sets = char_config.get("推荐套装", [])
            
            # 属性匹配
            if stat in recommended_stats:
                # 套装也匹配
                if set_name in recommended_sets:
                    return True, f"{char_name}推荐"
                elif not recommended_sets:  # 没指定套装则只看属性
                    return True, f"{char_name}推荐"
        
        return False, "无匹配"
    
    def lock_disc(self, x: int, y: int):
        """锁定驱动盘（模拟点击）"""
        if not self.window_rect:
            return
        
        # 计算屏幕绝对坐标
        screen_x = self.window_rect[0] + x
        screen_y = self.window_rect[1] + y
        
        try:
            # 移动到驱动盘位置
            pyautogui.moveTo(screen_x, screen_y, duration=0.3)
            time.sleep(0.2)
            
            # 右键点击打开菜单（或其他操作）
            # pyautogui.rightClick(screen_x, screen_y)
            
            logger.info(f"🔒 锁定位置：({x}, {y})")
        except Exception as e:
            logger.error(f"❌ 锁定失败：{e}")
    
    def scan_backpack(self):
        """扫描背包"""
        logger.info("🎒 开始扫描背包...")
        
        if not self.activate_window():
            logger.error("❌ 无法激活游戏窗口")
            return
        
        time.sleep(2)  # 等待窗口激活
        
        # 捕获画面
        image = self.capture_window()
        if image is None:
            logger.error("❌ 无法捕获画面")
            return
        
        # 定义驱动盘网格位置（需要根据实际 UI 校准）
        # 这里是示例值，实际需要用户校准
        grid_config = {
            "start_x": 100,
            "start_y": 150,
            "cell_width": 120,
            "cell_height": 120,
            "cols": 8,
            "rows": 5
        }
        
        self.scan_results = []
        
        # 遍历网格
        for row in range(grid_config["rows"]):
            for col in range(grid_config["cols"]):
                x = grid_config["start_x"] + col * grid_config["cell_width"]
                y = grid_config["start_y"] + row * grid_config["cell_height"]
                
                # 识别驱动盘
                disc = self.detect_drive_disc(image, x, y, 
                                              grid_config["cell_width"], 
                                              grid_config["cell_height"])
                
                if disc:
                    should_lock, reason = self.is_worth_locking(disc)
                    disc["should_lock"] = should_lock
                    disc["reason"] = reason
                    self.scan_results.append(disc)
                    
                    logger.info(f"📍 [{row},{col}] {disc['star']}星 {disc['stat'] or '?'} {disc['set']} - {reason}")
                    
                    if should_lock and self.config.get("lock_matching", True):
                        self.lock_disc(x, y)
                
                time.sleep(self.config.get("scan_delay", 0.5))
        
        logger.info(f"✅ 扫描完成，共发现 {len(self.scan_results)} 个驱动盘")
        self.generate_report()
    
    def generate_report(self):
        """生成扫描报告"""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = self.reports_dir / f"report_{ts}.html"
        
        # 统计
        total = len(self.scan_results)
        to_lock = sum(1 for d in self.scan_results if d.get("should_lock"))
        
        html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>驱动盘扫描报告 - {ts}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #1a1a2e; color: #eee; }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        h1 {{ color: #ff6b00; }}
        .summary {{ display: flex; gap: 20px; margin: 20px 0; }}
        .card {{ background: #16213e; padding: 20px; border-radius: 8px; flex: 1; }}
        .card h2 {{ margin: 0; color: #ff6b00; font-size: 36px; }}
        .card p {{ margin: 5px 0 0; color: #888; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 20px; }}
        th, td {{ border: 1px solid #333; padding: 10px; text-align: left; }}
        th {{ background: #16213e; color: #ff6b00; }}
        tr:nth-child(even) {{ background: #0f0f23; }}
        .lock {{ color: #52c41a; }}
        .skip {{ color: #888; }}
        .star5 {{ color: #ffb347; }}
        .star4 {{ color: #a06cd5; }}
        .star3 {{ color: #4da6ff; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🎮 绝区零驱动盘扫描报告</h1>
        <p>扫描时间：{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
        
        <div class="summary">
            <div class="card">
                <h2>{total}</h2>
                <p>扫描总数</p>
            </div>
            <div class="card">
                <h2>{to_lock}</h2>
                <p>建议锁定</p>
            </div>
            <div class="card">
                <h2>{total - to_lock}</h2>
                <p>跳过</p>
            </div>
        </div>
        
        <h2>📊 扫描结果</h2>
        <table>
            <thead>
                <tr><th>时间</th><th>星级</th><th>属性</th><th>套装</th><th>操作</th><th>原因</th></tr>
            </thead>
            <tbody>
"""
        
        for disc in self.scan_results:
            star_class = f"star{disc.get('star', 3)}"
            action = "<span class='lock'>🔒 锁定</span>" if disc.get("should_lock") else "<span class='skip'>⏭️ 跳过</span>"
            html += f"""<tr>
                <td>{disc.get('timestamp', '')}</td>
                <td class="{star_class}">{'⭐' * disc.get('star', 0)}</td>
                <td>{disc.get('stat', '未知')}</td>
                <td>{disc.get('set', '未知')}</td>
                <td>{action}</td>
                <td>{disc.get('reason', '')}</td>
            </tr>"""
        
        html += """</tbody></table></div></body></html>"""
        
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(html)
        
        logger.info(f"📄 报告已生成：{report_path}")
        
        # 自动打开报告
        import webbrowser
        webbrowser.open(str(report_path))
    
    def calibrate(self):
        """校准模式 - 帮助用户设置正确的坐标"""
        logger.info("🎯 进入校准模式...")
        
        if not self.activate_window():
            return
        
        print("\n" + "="*50)
        print("校准模式")
        print("="*50)
        print("请将鼠标移动到第一个驱动盘的左上角，然后按回车...")
        input()
        
        pos = pyautogui.position()
        print(f"位置 1: {pos}")
        
        print("请将鼠标移动到第二个驱动盘的左上角，然后按回车...")
        input()
        
        pos2 = pyautogui.position()
        print(f"位置 2: {pos2}")
        
        cell_width = pos2[0] - pos[0]
        cell_height = pos2[1] - pos[1]
        
        print(f"\n计算结果:")
        print(f"  起始位置：({pos[0]}, {pos[1]})")
        print(f"  单元格大小：{cell_width} x {cell_height}")
        print(f"\n请将这些值更新到 config.json")


def main():
    print("\n" + "="*60)
    print("🎮 绝区零驱动盘自动扫描工具")
    print("="*60 + "\n")
    
    scanner = DriveDiscScanner()
    
    print("请选择操作:")
    print("  1. 扫描背包")
    print("  2. 校准模式")
    print("  3. 退出")
    
    choice = input("\n输入选项 (1/2/3): ").strip()
    
    if choice == "1":
        print("\n⚠️ 请确保:")
        print("  1. 游戏已打开且为窗口模式")
        print("  2. 已进入背包 - 驱动盘页面")
        print("  3. 扫描过程中不要操作游戏")
        input("\n按回车开始扫描...")
        scanner.scan_backpack()
    elif choice == "2":
        scanner.calibrate()
    elif choice == "3":
        print("👋 再见!")
    else:
        print("❌ 无效选项")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n👋 用户中断")
    except Exception as e:
        logger.error(f"❌ 错误：{e}")
        import traceback
        traceback.print_exc()

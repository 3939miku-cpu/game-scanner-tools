@echo off
chcp 65001 >nul
echo ============================================
echo 🎮 绝区零驱动盘扫描工具
echo ============================================
echo.

REM 检查 Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ 未检测到 Python
    echo.
    echo 请访问：https://www.python.org/downloads/
    echo 下载并安装 Python
    echo 安装时勾选 "Add Python to PATH"
    echo.
    pause
    start https://www.python.org/downloads/
    exit /b 1
)

echo ✅ Python 已安装
echo.

REM 检查依赖
python -c "import cv2" >nul 2>&1
if errorlevel 1 (
    echo 📦 正在安装依赖库...
    pip install opencv-python numpy pyautogui pygetwindow pillow
    echo.
)

echo 🚀 启动扫描工具...
echo.
python scanner.py

echo.
pause
